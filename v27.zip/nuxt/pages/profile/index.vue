<script setup>
await loadTranslations("dashboard"); // load translation

const router = useRouter();
onMounted(() => {
  if (!Parse.User.current()) {
    router.push({ path: '/auth/sign-in' });
  }
})
</script>

<template>
  <div class="dark"><!-- enables tailwind darkmode, toggle this  -->
    <SideMenu>
    </SideMenu>
    <div></div>
    <button
      @click="
        {
          Parse.User.logOut();
          router.push({ path: '/auth/sign-in' });
        }
      "
    >
      Sign out!
    </button>
  </div>
</template>
