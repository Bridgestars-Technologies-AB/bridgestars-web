<template>
  <CardPageLayout title="test card page layout">
    
  </CardPageLayout>
</template>
