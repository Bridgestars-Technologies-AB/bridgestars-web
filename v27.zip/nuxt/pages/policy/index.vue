<template>
  <Policy></Policy>
</template>
