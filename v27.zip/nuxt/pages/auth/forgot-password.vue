<template>
  <div>Welcome to forgot pass</div>
</template>
