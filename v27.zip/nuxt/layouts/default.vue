<template>
  <div class="DefaultLayout">
    <slot></slot>
  </div>
</template>
