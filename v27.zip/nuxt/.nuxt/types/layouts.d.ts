import { ComputedRef, Ref } from 'vue'
export type LayoutKey = "default" | "sign-in"
declare module "/Users/theo/Documents/bridgestars/lib/bridgestars-web/nuxt/node_modules/nuxt/dist/pages/runtime/composables" {
  interface PageMeta {
    layout?: false | LayoutKey | Ref<LayoutKey> | ComputedRef<LayoutKey>
  }
}