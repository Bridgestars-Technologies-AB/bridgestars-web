const welcome = "Welcome";
const enUS = {
  welcome
};

export { enUS as default, welcome };
//# sourceMappingURL=en-US-13389a25.mjs.map
