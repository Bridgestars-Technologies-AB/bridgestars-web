import { _ as __nuxt_component_0$1, a as __nuxt_component_1, b as __nuxt_component_2 } from './parse.config-3c6817de.mjs';
import { useSSRContext, mergeProps, withCtx, createVNode, unref } from 'vue';
import { u as useRouter } from '../server.mjs';
import { ssrRenderComponent } from 'vue/server-renderer';
import Parse from 'parse/dist/parse.min.js';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'unstorage/drivers/fs';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import '@intlify/bundle-utils';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@intlify/core-base';
import 'cookie-es';
import 'is-https';
import 'vue-toastification';

const _sfc_main$1 = {
  __name: "SignUp",
  __ssrInlineRender: true,
  setup(__props) {
    const router = useRouter();
    function submit(res) {
      console.log(res);
      Parse.User.signUp(res.username, res.password, { email: res.email }).then((user) => {
        toast.success("You are signed up!");
        router.push({ path: "/profile" });
      }).catch((e) => toast.error(e.message));
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AuthForm = __nuxt_component_0$1;
      const _component_TextInputField = __nuxt_component_1;
      const _component_SubmitButton = __nuxt_component_2;
      _push(ssrRenderComponent(_component_AuthForm, mergeProps({
        header: " / Sign Up",
        title: "Join the Bridgestars waiting list",
        subtitle: "Enter your disired username below to create an account.",
        onSubmit: submit
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_TextInputField, {
              wrapperClass: "w-[100%]",
              placeholder: "Username",
              type: "username",
              id: "username"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_TextInputField, {
              wrapperClass: "w-[100%]",
              placeholder: "Email",
              type: "email",
              id: "email"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_TextInputField, {
              wrapperClass: "w-[100%]",
              placeholder: "Password",
              type: "password",
              id: "password"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_TextInputField, {
              wrapperClass: "w-[100%]",
              placeholder: "Confirm password",
              type: "password",
              id: "confirm-password"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_SubmitButton, {
              wrapperClass: "w-[100%] !mt-6",
              id: "submit",
              type: "submit",
              text: "SIGN UP",
              onSubmit: submit
            }, null, _parent2, _scopeId));
            _push2(`<div class="!mt-6"${_scopeId}><span class="text2"${_scopeId}>Already have an account? </span><button class="textButton buttonText normal-case"${_scopeId}> Sign In </button></div>`);
          } else {
            return [
              createVNode(_component_TextInputField, {
                wrapperClass: "w-[100%]",
                placeholder: "Username",
                type: "username",
                id: "username"
              }),
              createVNode(_component_TextInputField, {
                wrapperClass: "w-[100%]",
                placeholder: "Email",
                type: "email",
                id: "email"
              }),
              createVNode(_component_TextInputField, {
                wrapperClass: "w-[100%]",
                placeholder: "Password",
                type: "password",
                id: "password"
              }),
              createVNode(_component_TextInputField, {
                wrapperClass: "w-[100%]",
                placeholder: "Confirm password",
                type: "password",
                id: "confirm-password"
              }),
              createVNode(_component_SubmitButton, {
                wrapperClass: "w-[100%] !mt-6",
                id: "submit",
                type: "submit",
                text: "SIGN UP",
                onSubmit: submit
              }),
              createVNode("div", { class: "!mt-6" }, [
                createVNode("span", { class: "text2" }, "Already have an account? "),
                createVNode("button", {
                  onClick: ($event) => unref(router).push({ path: "/auth/sign-in" }),
                  class: "textButton buttonText normal-case"
                }, " Sign In ", 8, ["onClick"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/auth/SignUp.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$1;
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_SignUp = __nuxt_component_0;
  _push(ssrRenderComponent(_component_SignUp, _attrs, null, _parent));
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/auth/sign-up.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const signUp = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { signUp as default };
//# sourceMappingURL=sign-up-e79b164c.mjs.map
