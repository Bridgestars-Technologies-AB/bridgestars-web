const welcome = "V\xE4lkommen";
const svSE = {
  welcome
};

export { svSE as default, welcome };
//# sourceMappingURL=sv-SE-ad52f6f9.mjs.map
