import { _ as __nuxt_component_0, a as __nuxt_component_1, b as __nuxt_component_2 } from './parse.config-3c6817de.mjs';
import { useSSRContext, defineComponent, mergeProps, withCtx, createVNode, unref } from 'vue';
import { u as useRouter } from '../server.mjs';
import { useToast } from 'vue-toastification';
import { ssrRenderComponent } from 'vue/server-renderer';
import Parse from 'parse/dist/parse.min.js';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'unstorage/drivers/fs';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import '@intlify/bundle-utils';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@intlify/core-base';
import 'cookie-es';
import 'is-https';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "SignIn",
  __ssrInlineRender: true,
  setup(__props) {
    const router = useRouter();
    const toast = useToast();
    function submit(res) {
      Parse.User.logIn(res.usernameEmail, res.password).then((user) => {
        toast.success("You are signed in!");
        router.push({ path: "/profile" });
      }).catch((e) => toast.error(e.message));
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AuthForm = __nuxt_component_0;
      const _component_TextInputField = __nuxt_component_1;
      const _component_SubmitButton = __nuxt_component_2;
      _push(ssrRenderComponent(_component_AuthForm, mergeProps({
        header: " / Sign In",
        title: "Sign in to your Bridgestars account",
        subtitle: "Enter your username and password",
        onSubmit: submit
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_TextInputField, {
              wrapperClass: "w-[100%]",
              placeholder: "Username/Email",
              id: "usernameEmail"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_TextInputField, {
              wrapperClass: "w-[100%]",
              placeholder: "Password",
              type: "password",
              id: "password-signin"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_SubmitButton, {
              wrapperClass: "w-[100%] !mt-6",
              id: "submit",
              text: "SIGN IN"
            }, null, _parent2, _scopeId));
            _push2(`<div class="!mt-6 whitespace-nowrap"${_scopeId}><span class="text2"${_scopeId}>Don&#39;t have an account? </span><button class="textButton buttonText normal-case"${_scopeId}> Sign Up </button></div><div${_scopeId}><button class="textButton buttonText normal-case translate-y-[-12px]"${_scopeId}> Forgot your password? </button></div>`);
          } else {
            return [
              createVNode(_component_TextInputField, {
                wrapperClass: "w-[100%]",
                placeholder: "Username/Email",
                id: "usernameEmail"
              }),
              createVNode(_component_TextInputField, {
                wrapperClass: "w-[100%]",
                placeholder: "Password",
                type: "password",
                id: "password-signin"
              }),
              createVNode(_component_SubmitButton, {
                wrapperClass: "w-[100%] !mt-6",
                id: "submit",
                text: "SIGN IN"
              }),
              createVNode("div", { class: "!mt-6 whitespace-nowrap" }, [
                createVNode("span", { class: "text2" }, "Don't have an account? "),
                createVNode("button", {
                  onClick: ($event) => unref(router).push({ path: "/auth/sign-up" }),
                  class: "textButton buttonText normal-case"
                }, " Sign Up ", 8, ["onClick"])
              ]),
              createVNode("div", null, [
                createVNode("button", { class: "textButton buttonText normal-case translate-y-[-12px]" }, " Forgot your password? ")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/auth/SignIn.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_SignIn = _sfc_main$1;
  _push(ssrRenderComponent(_component_SignIn, _attrs, null, _parent));
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/auth/sign-in.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const signIn = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { signIn as default };
//# sourceMappingURL=sign-in-45a861f1.mjs.map
