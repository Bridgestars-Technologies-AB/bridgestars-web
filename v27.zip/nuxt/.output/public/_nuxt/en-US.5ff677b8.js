const e="Welcome",o={welcome:e};export{o as default,e as welcome};
