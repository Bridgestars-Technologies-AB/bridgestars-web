<template>
    <h1>Deal Editor</h1> 
</template>
