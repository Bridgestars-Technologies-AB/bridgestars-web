<template>
  <auth-reset/>
</template>
