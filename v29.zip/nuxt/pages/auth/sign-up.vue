<template>
  <auth-sign-up/> 
</template>
