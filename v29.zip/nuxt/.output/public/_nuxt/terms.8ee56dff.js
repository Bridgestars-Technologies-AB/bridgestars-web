import{_ as r}from"./_plugin-vue_export-helper.c27b6911.js";const e={};function t(c,n){return null}const s=r(e,[["render",t]]);export{s as default};
