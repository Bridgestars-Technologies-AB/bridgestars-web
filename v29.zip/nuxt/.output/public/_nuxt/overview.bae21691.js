import{k as e,o,c as t}from"./entry.504ac64a.js";const s={class:""},_={__name:"overview",setup(c){return e(()=>{}),(r,a)=>(o(),t("h1",s,"Overview"))}};export{_ as default};
