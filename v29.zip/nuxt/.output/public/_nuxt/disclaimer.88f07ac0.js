import{_ as r}from"./_plugin-vue_export-helper.c27b6911.js";const c={};function e(n,t){return null}const s=r(c,[["render",e]]);export{s as default};
