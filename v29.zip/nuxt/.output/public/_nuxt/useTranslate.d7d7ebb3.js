import{T as r}from"./entry.504ac64a.js";function a(){const{t,i18next:n}=r();return{t,i18:n}}export{a as u};
