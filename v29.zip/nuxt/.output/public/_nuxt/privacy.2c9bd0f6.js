import{_ as r}from"./_plugin-vue_export-helper.c27b6911.js";const c={};function e(n,t){return null}const o=r(c,[["render",e]]);export{o as default};
