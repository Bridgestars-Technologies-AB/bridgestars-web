import{_ as r}from"./_plugin-vue_export-helper.c27b6911.js";const c={};function t(e,n){return null}const o=r(c,[["render",t]]);export{o as default};
