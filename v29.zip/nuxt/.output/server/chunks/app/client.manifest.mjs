const client_manifest = {
  "__plugin-vue_export-helper.c27b6911.js": {
    "resourceType": "script",
    "module": true,
    "file": "_plugin-vue_export-helper.c27b6911.js"
  },
  "_card-page-layout.87c377d5.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "logo-trans-128px.c1860341.png",
      "facebook-dark.51a57591.svg",
      "instagram-dark.e71ede31.svg",
      "discord-dark.8c651974.svg"
    ],
    "css": [
      "card-page-layout.0678e0b4.css"
    ],
    "file": "card-page-layout.87c377d5.js",
    "imports": [
      "_nuxt-link.3fbcb472.js",
      "_hamburger-menu-button.1e2d10f9.js",
      "_useTranslate.d7d7ebb3.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ]
  },
  "card-page-layout.0678e0b4.css": {
    "file": "card-page-layout.0678e0b4.css",
    "resourceType": "style"
  },
  "logo-trans-128px.c1860341.png": {
    "file": "logo-trans-128px.c1860341.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "facebook-dark.51a57591.svg": {
    "file": "facebook-dark.51a57591.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "instagram-dark.e71ede31.svg": {
    "file": "instagram-dark.e71ede31.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "discord-dark.8c651974.svg": {
    "file": "discord-dark.8c651974.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "_form.3809ebd5.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "auth-form-suits.fbea51fd.svg",
      "auth-form-ipad.2b33d4ce.svg",
      "sign_in.1171b396.svg",
      "logo-trans-512px.6894ce8f.png"
    ],
    "css": [
      "form.e0e9c2c5.css"
    ],
    "file": "form.3809ebd5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_useTranslate.d7d7ebb3.js"
    ]
  },
  "form.e0e9c2c5.css": {
    "file": "form.e0e9c2c5.css",
    "resourceType": "style"
  },
  "auth-form-suits.fbea51fd.svg": {
    "file": "auth-form-suits.fbea51fd.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "auth-form-ipad.2b33d4ce.svg": {
    "file": "auth-form-ipad.2b33d4ce.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "sign_in.1171b396.svg": {
    "file": "sign_in.1171b396.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "logo-trans-512px.6894ce8f.png": {
    "file": "logo-trans-512px.6894ce8f.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "_hamburger-menu-button.1e2d10f9.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "hamburger-menu-button.f02900c1.css"
    ],
    "file": "hamburger-menu-button.1e2d10f9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ]
  },
  "hamburger-menu-button.f02900c1.css": {
    "file": "hamburger-menu-button.f02900c1.css",
    "resourceType": "style"
  },
  "_lang-switcher.712b1654.js": {
    "resourceType": "script",
    "module": true,
    "file": "lang-switcher.712b1654.js",
    "imports": [
      "_useTranslate.d7d7ebb3.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_nuxt-link.3fbcb472.js": {
    "resourceType": "script",
    "module": true,
    "file": "nuxt-link.3fbcb472.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useTranslate.d7d7ebb3.js": {
    "resourceType": "script",
    "module": true,
    "file": "useTranslate.d7d7ebb3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "assets/bridgestars/art/auth-form-ipad.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "auth-form-ipad.2b33d4ce.svg",
    "src": "assets/bridgestars/art/auth-form-ipad.svg"
  },
  "assets/bridgestars/art/auth-form-suits.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "auth-form-suits.fbea51fd.svg",
    "src": "assets/bridgestars/art/auth-form-suits.svg"
  },
  "assets/bridgestars/art/sign_in.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "sign_in.1171b396.svg",
    "src": "assets/bridgestars/art/sign_in.svg"
  },
  "assets/bridgestars/images/castor-square.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "castor-square.6080d437.jpg",
    "src": "assets/bridgestars/images/castor-square.jpg"
  },
  "assets/bridgestars/images/castor.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "castor.f4af3c0a.jpg",
    "src": "assets/bridgestars/images/castor.jpg"
  },
  "assets/bridgestars/images/shortIntroLastFrame.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "shortIntroLastFrame.f94ad735.jpg",
    "src": "assets/bridgestars/images/shortIntroLastFrame.jpg"
  },
  "assets/bridgestars/logo/logo-trans-128px.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo-trans-128px.c1860341.png",
    "src": "assets/bridgestars/logo/logo-trans-128px.png"
  },
  "assets/bridgestars/logo/logo-trans-512px.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo-trans-512px.6894ce8f.png",
    "src": "assets/bridgestars/logo/logo-trans-512px.png"
  },
  "assets/bridgestars/video/shortIntro-compressed.mp4": {
    "resourceType": "video",
    "file": "shortIntro-compressed.e6839cd4.mp4",
    "src": "assets/bridgestars/video/shortIntro-compressed.mp4"
  },
  "assets/logo/discord-dark.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "discord-dark.8c651974.svg",
    "src": "assets/logo/discord-dark.svg"
  },
  "assets/logo/facebook-dark.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "facebook-dark.51a57591.svg",
    "src": "assets/logo/facebook-dark.svg"
  },
  "assets/logo/instagram-dark.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "instagram-dark.e71ede31.svg",
    "src": "assets/logo/instagram-dark.svg"
  },
  "card-page-layout.css": {
    "resourceType": "style",
    "file": "card-page-layout.0678e0b4.css",
    "src": "card-page-layout.css"
  },
  "form.css": {
    "resourceType": "style",
    "file": "form.e0e9c2c5.css",
    "src": "form.css"
  },
  "hamburger-menu-button.css": {
    "resourceType": "style",
    "file": "hamburger-menu-button.f02900c1.css",
    "src": "hamburger-menu-button.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "file": "default.65a85670.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "layouts/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "file": "sign-in.a7922995.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/sign-in.vue"
  },
  "localization/en/auth.json": {
    "resourceType": "script",
    "module": true,
    "file": "auth.6a0edeb5.js",
    "isDynamicEntry": true,
    "src": "localization/en/auth.json"
  },
  "localization/en/common.json": {
    "resourceType": "script",
    "module": true,
    "file": "common.80dd8372.js",
    "isDynamicEntry": true,
    "src": "localization/en/common.json"
  },
  "localization/en/dashboard.json": {
    "resourceType": "script",
    "module": true,
    "file": "dashboard.412ea626.js",
    "isDynamicEntry": true,
    "src": "localization/en/dashboard.json"
  },
  "localization/en/download.json": {
    "resourceType": "script",
    "module": true,
    "file": "download.5e7faa9b.js",
    "isDynamicEntry": true,
    "src": "localization/en/download.json"
  },
  "localization/en/home.json": {
    "resourceType": "script",
    "module": true,
    "file": "home.8eb6ed3b.js",
    "isDynamicEntry": true,
    "src": "localization/en/home.json"
  },
  "localization/sv/auth.json": {
    "resourceType": "script",
    "module": true,
    "file": "auth.8354c91f.js",
    "isDynamicEntry": true,
    "src": "localization/sv/auth.json"
  },
  "localization/sv/common.json": {
    "resourceType": "script",
    "module": true,
    "file": "common.ab5a0082.js",
    "isDynamicEntry": true,
    "src": "localization/sv/common.json"
  },
  "localization/sv/dashboard.json": {
    "resourceType": "script",
    "module": true,
    "file": "dashboard.1ad0a377.js",
    "isDynamicEntry": true,
    "src": "localization/sv/dashboard.json"
  },
  "localization/sv/download.json": {
    "resourceType": "script",
    "module": true,
    "file": "download.9b16b376.js",
    "isDynamicEntry": true,
    "src": "localization/sv/download.json"
  },
  "localization/sv/home.json": {
    "resourceType": "script",
    "module": true,
    "file": "home.dee2edfa.js",
    "isDynamicEntry": true,
    "src": "localization/sv/home.json"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-100-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-100-normal.c15ded35.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-100-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-100-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-100-normal.13162ed2.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-100-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-200-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-200-normal.e06789b3.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-200-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-200-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-200-normal.60726f57.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-200-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-300-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-300-normal.f0500af0.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-300-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-300-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-300-normal.cfc1dfa2.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-300-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-400-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-400-normal.48500c8f.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-400-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-400-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-400-normal.42aa362d.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-400-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-500-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-500-normal.34c3311c.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-500-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-500-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-500-normal.fd7f4d48.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-500-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-600-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-600-normal.32f4dca6.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-600-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-600-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-600-normal.a903a5ae.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-600-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-700-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-700-normal.e735a264.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-700-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-700-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-700-normal.36713511.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-700-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-800-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-800-normal.f50cc6dd.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-800-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-800-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-800-normal.dbbcf182.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-800-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-900-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-900-normal.e3e9e1a5.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-900-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-900-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-900-normal.e45320b7.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-900-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-100-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-ext-100-normal.67f8408b.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-100-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-100-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-ext-100-normal.b67c2aba.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-100-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-200-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-ext-200-normal.49acaf29.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-200-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-200-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-ext-200-normal.0905ab2e.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-200-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-300-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-ext-300-normal.8d4b98c0.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-300-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-300-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-ext-300-normal.d14bf70a.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-300-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-400-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-ext-400-normal.c250e40d.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-400-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-400-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-ext-400-normal.74e54082.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-400-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-500-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-ext-500-normal.8d476a02.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-500-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-500-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-ext-500-normal.5ea4d794.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-500-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-600-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-ext-600-normal.0aaac7ce.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-600-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-600-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-ext-600-normal.8a7d145f.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-600-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-700-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-ext-700-normal.8a6a5661.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-700-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-700-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-ext-700-normal.9b276e65.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-700-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-800-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-ext-800-normal.b5da902a.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-800-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-800-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-ext-800-normal.9cbc0ba0.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-800-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-900-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-cyrillic-ext-900-normal.5a22120a.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-900-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-900-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-cyrillic-ext-900-normal.0d671900.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-cyrillic-ext-900-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-100-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-greek-100-normal.e0e368f3.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-100-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-100-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-greek-100-normal.569dab63.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-100-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-200-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-greek-200-normal.bf515d89.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-200-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-200-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-greek-200-normal.7a1b6689.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-200-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-300-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-greek-300-normal.9c41a862.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-300-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-300-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-greek-300-normal.ae4340bf.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-300-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-400-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-greek-400-normal.1e4355f9.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-400-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-400-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-greek-400-normal.df102cdd.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-400-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-500-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-greek-500-normal.c9a3f4d8.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-500-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-500-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-greek-500-normal.bf7622b6.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-500-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-600-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-greek-600-normal.7e321e5b.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-600-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-600-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-greek-600-normal.962dc948.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-600-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-700-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-greek-700-normal.b7ecff05.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-700-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-700-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-greek-700-normal.e19b129f.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-700-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-800-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-greek-800-normal.a4cd9f84.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-800-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-800-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-greek-800-normal.9a482692.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-800-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-900-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-greek-900-normal.b326ae79.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-900-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-900-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-greek-900-normal.5191456f.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-greek-900-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-100-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-100-normal.ba5236ba.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-100-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-100-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-100-normal.2090987a.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-100-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-200-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-200-normal.78146ad8.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-200-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-200-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-200-normal.a13f9df7.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-200-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-300-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-300-normal.6dd87d27.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-300-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-300-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-300-normal.deaa5eca.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-300-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-400-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-400-normal.a5a377de.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-400-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-400-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-400-normal.e3b93a1b.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-400-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-500-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-500-normal.b306c48a.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-500-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-500-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-500-normal.c6e91c8c.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-500-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-600-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-600-normal.9ff01a0a.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-600-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-600-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-600-normal.f6b0025a.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-600-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-700-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-700-normal.6e5a88ee.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-700-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-700-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-700-normal.084c044e.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-700-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-800-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-800-normal.ba159e07.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-800-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-800-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-800-normal.456a3936.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-800-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-900-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-900-normal.32a00763.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-900-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-900-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-900-normal.55e1d740.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-900-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-100-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-ext-100-normal.3dc9d0f4.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-100-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-100-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-ext-100-normal.6bc091ed.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-100-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-200-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-ext-200-normal.a41c6b9b.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-200-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-200-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-ext-200-normal.9fcc3aa5.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-200-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-300-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-ext-300-normal.615e8295.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-300-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-300-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-ext-300-normal.0bb1b214.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-300-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-400-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-ext-400-normal.c8bafe5f.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-400-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-400-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-ext-400-normal.befc8883.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-400-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-500-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-ext-500-normal.1c495911.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-500-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-500-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-ext-500-normal.da7c260f.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-500-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-600-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-ext-600-normal.1ab27ab3.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-600-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-600-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-ext-600-normal.28e02f06.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-600-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-700-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-ext-700-normal.ee76cba0.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-700-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-700-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-ext-700-normal.03ee983f.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-700-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-800-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-ext-800-normal.675f48ba.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-800-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-800-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-ext-800-normal.4d7ba76c.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-800-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-900-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-latin-ext-900-normal.6392b1e5.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-900-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-900-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-slab-latin-ext-900-normal.37bbacd9.woff2",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-latin-ext-900-normal.woff2"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-100-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-vietnamese-100-normal.52b4078a.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-100-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-200-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-vietnamese-200-normal.d35d2a72.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-200-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-300-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-vietnamese-300-normal.3693aa95.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-300-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-400-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-vietnamese-400-normal.00b055dc.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-400-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-500-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-vietnamese-500-normal.6763c1b9.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-500-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-600-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-vietnamese-600-normal.641fd082.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-600-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-700-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-vietnamese-700-normal.4a05efcc.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-700-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-800-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-vietnamese-800-normal.1250ab68.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-800-normal.woff"
  },
  "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-900-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-slab-vietnamese-900-normal.570ce4f2.woff",
    "src": "node_modules/@fontsource/roboto-slab/files/roboto-slab-vietnamese-900-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-100-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-cyrillic-100-normal.c66effb1.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-100-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-100-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-cyrillic-100-normal.638764dc.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-100-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-300-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-cyrillic-300-normal.c07952fe.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-300-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-300-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-cyrillic-300-normal.47aa3bfa.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-300-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-400-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-cyrillic-400-normal.adba67d2.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-400-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-400-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-cyrillic-400-normal.495d38d4.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-400-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-500-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-cyrillic-500-normal.4bc088e9.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-500-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-500-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-cyrillic-500-normal.3728fbdd.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-500-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-700-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-cyrillic-700-normal.6f82c5e2.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-700-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-700-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-cyrillic-700-normal.6a84eeee.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-700-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-900-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-cyrillic-900-normal.c917b854.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-900-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-900-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-cyrillic-900-normal.9fdb12ce.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-900-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-100-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-cyrillic-ext-100-normal.4037eed1.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-100-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-100-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-cyrillic-ext-100-normal.8e48cf20.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-100-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-300-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-cyrillic-ext-300-normal.5e06c977.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-300-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-300-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-cyrillic-ext-300-normal.435e4b7f.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-300-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-400-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-cyrillic-ext-400-normal.0a32035a.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-400-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-400-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-cyrillic-ext-400-normal.b7ef2cd1.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-400-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-500-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-cyrillic-ext-500-normal.57138788.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-500-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-500-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-cyrillic-ext-500-normal.aeed0e51.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-500-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-700-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-cyrillic-ext-700-normal.8ea7934f.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-700-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-700-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-cyrillic-ext-700-normal.3c505383.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-700-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-900-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-cyrillic-ext-900-normal.8d3d12a5.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-900-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-900-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-cyrillic-ext-900-normal.f265cee6.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-cyrillic-ext-900-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-greek-100-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-greek-100-normal.a4022948.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-greek-100-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-greek-100-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-greek-100-normal.8c3798e3.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-greek-100-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-greek-300-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-greek-300-normal.6bb1ef10.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-greek-300-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-greek-300-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-greek-300-normal.455c2c1a.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-greek-300-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-greek-400-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-greek-400-normal.076b9dc1.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-greek-400-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-greek-400-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-greek-400-normal.daf51ab5.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-greek-400-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-greek-500-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-greek-500-normal.93181eb7.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-greek-500-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-greek-500-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-greek-500-normal.713780d8.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-greek-500-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-greek-700-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-greek-700-normal.3f1a5012.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-greek-700-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-greek-700-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-greek-700-normal.1c9cc76f.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-greek-700-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-greek-900-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-greek-900-normal.8615b4aa.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-greek-900-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-greek-900-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-greek-900-normal.2550c2e2.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-greek-900-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-100-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-latin-100-normal.090d448c.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-100-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-100-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-latin-100-normal.0f303f31.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-100-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-300-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-latin-300-normal.ddb5c61d.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-300-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-300-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-latin-300-normal.f7591131.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-300-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-400-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-latin-400-normal.a9fdbefa.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-400-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-400-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-latin-400-normal.f6734f81.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-400-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-500-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-latin-500-normal.3ac31048.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-500-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-500-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-latin-500-normal.b0195382.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-500-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-700-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-latin-700-normal.d89bc0fc.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-700-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-700-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-latin-700-normal.f5aebdfe.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-700-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-900-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-latin-900-normal.730f633f.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-900-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-900-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-latin-900-normal.7e262106.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-900-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-ext-100-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-latin-ext-100-normal.ceee6016.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-ext-100-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-ext-100-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-latin-ext-100-normal.10b31f4c.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-ext-100-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-ext-300-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-latin-ext-300-normal.35da7ccd.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-ext-300-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-ext-300-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-latin-ext-300-normal.b076e863.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-ext-300-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-ext-400-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-latin-ext-400-normal.c2b94086.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-ext-400-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-ext-400-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-latin-ext-400-normal.3c23eb02.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-ext-400-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-ext-500-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-latin-ext-500-normal.a303676a.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-ext-500-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-ext-500-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-latin-ext-500-normal.7f1c829b.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-ext-500-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-ext-700-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-latin-ext-700-normal.3d1cbacf.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-ext-700-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-ext-700-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-latin-ext-700-normal.fc66f942.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-ext-700-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-ext-900-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-latin-ext-900-normal.45d477a3.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-ext-900-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-latin-ext-900-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-latin-ext-900-normal.2781e9e7.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-latin-ext-900-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-vietnamese-100-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-vietnamese-100-normal.900bd675.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-vietnamese-100-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-vietnamese-100-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-vietnamese-100-normal.ca7eea0c.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-vietnamese-100-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-vietnamese-300-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-vietnamese-300-normal.7747ef64.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-vietnamese-300-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-vietnamese-300-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-vietnamese-300-normal.51f3f418.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-vietnamese-300-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-vietnamese-400-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-vietnamese-400-normal.d2390f1a.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-vietnamese-400-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-vietnamese-400-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-vietnamese-400-normal.77b24796.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-vietnamese-400-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-vietnamese-500-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-vietnamese-500-normal.7899e6a5.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-vietnamese-500-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-vietnamese-500-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-vietnamese-500-normal.0948409a.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-vietnamese-500-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-vietnamese-700-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-vietnamese-700-normal.d986b503.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-vietnamese-700-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-vietnamese-700-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-vietnamese-700-normal.4ec57f2a.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-vietnamese-700-normal.woff2"
  },
  "node_modules/@fontsource/roboto/files/roboto-vietnamese-900-normal.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "roboto-vietnamese-900-normal.337a94bc.woff",
    "src": "node_modules/@fontsource/roboto/files/roboto-vietnamese-900-normal.woff"
  },
  "node_modules/@fontsource/roboto/files/roboto-vietnamese-900-normal.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "roboto-vietnamese-900-normal.3a38c967.woff2",
    "src": "node_modules/@fontsource/roboto/files/roboto-vietnamese-900-normal.woff2"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.23f2309d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.47f9b66d.js",
    "imports": [
      "_nuxt-link.3fbcb472.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.23f2309d.css": {
    "file": "error-404.23f2309d.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.aa16ed4d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.8758f4c0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.aa16ed4d.css": {
    "file": "error-500.aa16ed4d.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.2e358bab.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "roboto-slab-cyrillic-ext-100-normal.b67c2aba.woff2",
      "roboto-slab-cyrillic-ext-100-normal.67f8408b.woff",
      "roboto-slab-cyrillic-100-normal.13162ed2.woff2",
      "roboto-slab-cyrillic-100-normal.c15ded35.woff",
      "roboto-slab-greek-100-normal.569dab63.woff2",
      "roboto-slab-greek-100-normal.e0e368f3.woff",
      "roboto-slab-vietnamese-100-normal.52b4078a.woff",
      "roboto-slab-latin-ext-100-normal.6bc091ed.woff2",
      "roboto-slab-latin-ext-100-normal.3dc9d0f4.woff",
      "roboto-slab-latin-100-normal.2090987a.woff2",
      "roboto-slab-latin-100-normal.ba5236ba.woff",
      "roboto-slab-cyrillic-ext-200-normal.0905ab2e.woff2",
      "roboto-slab-cyrillic-ext-200-normal.49acaf29.woff",
      "roboto-slab-cyrillic-200-normal.60726f57.woff2",
      "roboto-slab-cyrillic-200-normal.e06789b3.woff",
      "roboto-slab-greek-200-normal.7a1b6689.woff2",
      "roboto-slab-greek-200-normal.bf515d89.woff",
      "roboto-slab-vietnamese-200-normal.d35d2a72.woff",
      "roboto-slab-latin-ext-200-normal.9fcc3aa5.woff2",
      "roboto-slab-latin-ext-200-normal.a41c6b9b.woff",
      "roboto-slab-latin-200-normal.a13f9df7.woff2",
      "roboto-slab-latin-200-normal.78146ad8.woff",
      "roboto-slab-cyrillic-ext-300-normal.d14bf70a.woff2",
      "roboto-slab-cyrillic-ext-300-normal.8d4b98c0.woff",
      "roboto-slab-cyrillic-300-normal.cfc1dfa2.woff2",
      "roboto-slab-cyrillic-300-normal.f0500af0.woff",
      "roboto-slab-greek-300-normal.ae4340bf.woff2",
      "roboto-slab-greek-300-normal.9c41a862.woff",
      "roboto-slab-vietnamese-300-normal.3693aa95.woff",
      "roboto-slab-latin-ext-300-normal.0bb1b214.woff2",
      "roboto-slab-latin-ext-300-normal.615e8295.woff",
      "roboto-slab-latin-300-normal.deaa5eca.woff2",
      "roboto-slab-latin-300-normal.6dd87d27.woff",
      "roboto-slab-cyrillic-ext-400-normal.74e54082.woff2",
      "roboto-slab-cyrillic-ext-400-normal.c250e40d.woff",
      "roboto-slab-cyrillic-400-normal.42aa362d.woff2",
      "roboto-slab-cyrillic-400-normal.48500c8f.woff",
      "roboto-slab-greek-400-normal.df102cdd.woff2",
      "roboto-slab-greek-400-normal.1e4355f9.woff",
      "roboto-slab-vietnamese-400-normal.00b055dc.woff",
      "roboto-slab-latin-ext-400-normal.befc8883.woff2",
      "roboto-slab-latin-ext-400-normal.c8bafe5f.woff",
      "roboto-slab-latin-400-normal.e3b93a1b.woff2",
      "roboto-slab-latin-400-normal.a5a377de.woff",
      "roboto-slab-cyrillic-ext-500-normal.5ea4d794.woff2",
      "roboto-slab-cyrillic-ext-500-normal.8d476a02.woff",
      "roboto-slab-cyrillic-500-normal.fd7f4d48.woff2",
      "roboto-slab-cyrillic-500-normal.34c3311c.woff",
      "roboto-slab-greek-500-normal.bf7622b6.woff2",
      "roboto-slab-greek-500-normal.c9a3f4d8.woff",
      "roboto-slab-vietnamese-500-normal.6763c1b9.woff",
      "roboto-slab-latin-ext-500-normal.da7c260f.woff2",
      "roboto-slab-latin-ext-500-normal.1c495911.woff",
      "roboto-slab-latin-500-normal.c6e91c8c.woff2",
      "roboto-slab-latin-500-normal.b306c48a.woff",
      "roboto-slab-cyrillic-ext-600-normal.8a7d145f.woff2",
      "roboto-slab-cyrillic-ext-600-normal.0aaac7ce.woff",
      "roboto-slab-cyrillic-600-normal.a903a5ae.woff2",
      "roboto-slab-cyrillic-600-normal.32f4dca6.woff",
      "roboto-slab-greek-600-normal.962dc948.woff2",
      "roboto-slab-greek-600-normal.7e321e5b.woff",
      "roboto-slab-vietnamese-600-normal.641fd082.woff",
      "roboto-slab-latin-ext-600-normal.28e02f06.woff2",
      "roboto-slab-latin-ext-600-normal.1ab27ab3.woff",
      "roboto-slab-latin-600-normal.f6b0025a.woff2",
      "roboto-slab-latin-600-normal.9ff01a0a.woff",
      "roboto-slab-cyrillic-ext-700-normal.9b276e65.woff2",
      "roboto-slab-cyrillic-ext-700-normal.8a6a5661.woff",
      "roboto-slab-cyrillic-700-normal.36713511.woff2",
      "roboto-slab-cyrillic-700-normal.e735a264.woff",
      "roboto-slab-greek-700-normal.e19b129f.woff2",
      "roboto-slab-greek-700-normal.b7ecff05.woff",
      "roboto-slab-vietnamese-700-normal.4a05efcc.woff",
      "roboto-slab-latin-ext-700-normal.03ee983f.woff2",
      "roboto-slab-latin-ext-700-normal.ee76cba0.woff",
      "roboto-slab-latin-700-normal.084c044e.woff2",
      "roboto-slab-latin-700-normal.6e5a88ee.woff",
      "roboto-slab-cyrillic-ext-800-normal.9cbc0ba0.woff2",
      "roboto-slab-cyrillic-ext-800-normal.b5da902a.woff",
      "roboto-slab-cyrillic-800-normal.dbbcf182.woff2",
      "roboto-slab-cyrillic-800-normal.f50cc6dd.woff",
      "roboto-slab-greek-800-normal.9a482692.woff2",
      "roboto-slab-greek-800-normal.a4cd9f84.woff",
      "roboto-slab-vietnamese-800-normal.1250ab68.woff",
      "roboto-slab-latin-ext-800-normal.4d7ba76c.woff2",
      "roboto-slab-latin-ext-800-normal.675f48ba.woff",
      "roboto-slab-latin-800-normal.456a3936.woff2",
      "roboto-slab-latin-800-normal.ba159e07.woff",
      "roboto-slab-cyrillic-ext-900-normal.0d671900.woff2",
      "roboto-slab-cyrillic-ext-900-normal.5a22120a.woff",
      "roboto-slab-cyrillic-900-normal.e45320b7.woff2",
      "roboto-slab-cyrillic-900-normal.e3e9e1a5.woff",
      "roboto-slab-greek-900-normal.5191456f.woff2",
      "roboto-slab-greek-900-normal.b326ae79.woff",
      "roboto-slab-vietnamese-900-normal.570ce4f2.woff",
      "roboto-slab-latin-ext-900-normal.37bbacd9.woff2",
      "roboto-slab-latin-ext-900-normal.6392b1e5.woff",
      "roboto-slab-latin-900-normal.55e1d740.woff2",
      "roboto-slab-latin-900-normal.32a00763.woff",
      "roboto-cyrillic-ext-100-normal.8e48cf20.woff2",
      "roboto-cyrillic-ext-100-normal.4037eed1.woff",
      "roboto-cyrillic-100-normal.638764dc.woff2",
      "roboto-cyrillic-100-normal.c66effb1.woff",
      "roboto-greek-100-normal.8c3798e3.woff2",
      "roboto-greek-100-normal.a4022948.woff",
      "roboto-vietnamese-100-normal.ca7eea0c.woff2",
      "roboto-vietnamese-100-normal.900bd675.woff",
      "roboto-latin-ext-100-normal.10b31f4c.woff2",
      "roboto-latin-ext-100-normal.ceee6016.woff",
      "roboto-latin-100-normal.0f303f31.woff2",
      "roboto-latin-100-normal.090d448c.woff",
      "roboto-cyrillic-ext-300-normal.435e4b7f.woff2",
      "roboto-cyrillic-ext-300-normal.5e06c977.woff",
      "roboto-cyrillic-300-normal.47aa3bfa.woff2",
      "roboto-cyrillic-300-normal.c07952fe.woff",
      "roboto-greek-300-normal.455c2c1a.woff2",
      "roboto-greek-300-normal.6bb1ef10.woff",
      "roboto-vietnamese-300-normal.51f3f418.woff2",
      "roboto-vietnamese-300-normal.7747ef64.woff",
      "roboto-latin-ext-300-normal.b076e863.woff2",
      "roboto-latin-ext-300-normal.35da7ccd.woff",
      "roboto-latin-300-normal.f7591131.woff2",
      "roboto-latin-300-normal.ddb5c61d.woff",
      "roboto-cyrillic-ext-400-normal.b7ef2cd1.woff2",
      "roboto-cyrillic-ext-400-normal.0a32035a.woff",
      "roboto-cyrillic-400-normal.495d38d4.woff2",
      "roboto-cyrillic-400-normal.adba67d2.woff",
      "roboto-greek-400-normal.daf51ab5.woff2",
      "roboto-greek-400-normal.076b9dc1.woff",
      "roboto-vietnamese-400-normal.77b24796.woff2",
      "roboto-vietnamese-400-normal.d2390f1a.woff",
      "roboto-latin-ext-400-normal.3c23eb02.woff2",
      "roboto-latin-ext-400-normal.c2b94086.woff",
      "roboto-latin-400-normal.f6734f81.woff2",
      "roboto-latin-400-normal.a9fdbefa.woff",
      "roboto-cyrillic-ext-500-normal.aeed0e51.woff2",
      "roboto-cyrillic-ext-500-normal.57138788.woff",
      "roboto-cyrillic-500-normal.3728fbdd.woff2",
      "roboto-cyrillic-500-normal.4bc088e9.woff",
      "roboto-greek-500-normal.713780d8.woff2",
      "roboto-greek-500-normal.93181eb7.woff",
      "roboto-vietnamese-500-normal.0948409a.woff2",
      "roboto-vietnamese-500-normal.7899e6a5.woff",
      "roboto-latin-ext-500-normal.7f1c829b.woff2",
      "roboto-latin-ext-500-normal.a303676a.woff",
      "roboto-latin-500-normal.b0195382.woff2",
      "roboto-latin-500-normal.3ac31048.woff",
      "roboto-cyrillic-ext-700-normal.3c505383.woff2",
      "roboto-cyrillic-ext-700-normal.8ea7934f.woff",
      "roboto-cyrillic-700-normal.6a84eeee.woff2",
      "roboto-cyrillic-700-normal.6f82c5e2.woff",
      "roboto-greek-700-normal.1c9cc76f.woff2",
      "roboto-greek-700-normal.3f1a5012.woff",
      "roboto-vietnamese-700-normal.4ec57f2a.woff2",
      "roboto-vietnamese-700-normal.d986b503.woff",
      "roboto-latin-ext-700-normal.fc66f942.woff2",
      "roboto-latin-ext-700-normal.3d1cbacf.woff",
      "roboto-latin-700-normal.f5aebdfe.woff2",
      "roboto-latin-700-normal.d89bc0fc.woff",
      "roboto-cyrillic-ext-900-normal.f265cee6.woff2",
      "roboto-cyrillic-ext-900-normal.8d3d12a5.woff",
      "roboto-cyrillic-900-normal.9fdb12ce.woff2",
      "roboto-cyrillic-900-normal.c917b854.woff",
      "roboto-greek-900-normal.2550c2e2.woff2",
      "roboto-greek-900-normal.8615b4aa.woff",
      "roboto-vietnamese-900-normal.3a38c967.woff2",
      "roboto-vietnamese-900-normal.337a94bc.woff",
      "roboto-latin-ext-900-normal.2781e9e7.woff2",
      "roboto-latin-ext-900-normal.45d477a3.woff",
      "roboto-latin-900-normal.7e262106.woff2",
      "roboto-latin-900-normal.730f633f.woff"
    ],
    "css": [
      "entry.2e358bab.css"
    ],
    "dynamicImports": [
      "layouts/default.vue",
      "layouts/sign-in.vue",
      "localization/en/auth.json",
      "localization/en/common.json",
      "localization/en/dashboard.json",
      "localization/en/download.json",
      "localization/en/home.json",
      "localization/sv/auth.json",
      "localization/sv/common.json",
      "localization/sv/dashboard.json",
      "localization/sv/download.json",
      "localization/sv/home.json",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.504ac64a.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.2e358bab.css": {
    "file": "entry.2e358bab.css",
    "resourceType": "style"
  },
  "roboto-slab-cyrillic-ext-100-normal.b67c2aba.woff2": {
    "file": "roboto-slab-cyrillic-ext-100-normal.b67c2aba.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-ext-100-normal.67f8408b.woff": {
    "file": "roboto-slab-cyrillic-ext-100-normal.67f8408b.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-cyrillic-100-normal.13162ed2.woff2": {
    "file": "roboto-slab-cyrillic-100-normal.13162ed2.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-100-normal.c15ded35.woff": {
    "file": "roboto-slab-cyrillic-100-normal.c15ded35.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-greek-100-normal.569dab63.woff2": {
    "file": "roboto-slab-greek-100-normal.569dab63.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-greek-100-normal.e0e368f3.woff": {
    "file": "roboto-slab-greek-100-normal.e0e368f3.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-vietnamese-100-normal.52b4078a.woff": {
    "file": "roboto-slab-vietnamese-100-normal.52b4078a.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-ext-100-normal.6bc091ed.woff2": {
    "file": "roboto-slab-latin-ext-100-normal.6bc091ed.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-ext-100-normal.3dc9d0f4.woff": {
    "file": "roboto-slab-latin-ext-100-normal.3dc9d0f4.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-100-normal.2090987a.woff2": {
    "file": "roboto-slab-latin-100-normal.2090987a.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-100-normal.ba5236ba.woff": {
    "file": "roboto-slab-latin-100-normal.ba5236ba.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-cyrillic-ext-200-normal.0905ab2e.woff2": {
    "file": "roboto-slab-cyrillic-ext-200-normal.0905ab2e.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-ext-200-normal.49acaf29.woff": {
    "file": "roboto-slab-cyrillic-ext-200-normal.49acaf29.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-cyrillic-200-normal.60726f57.woff2": {
    "file": "roboto-slab-cyrillic-200-normal.60726f57.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-200-normal.e06789b3.woff": {
    "file": "roboto-slab-cyrillic-200-normal.e06789b3.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-greek-200-normal.7a1b6689.woff2": {
    "file": "roboto-slab-greek-200-normal.7a1b6689.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-greek-200-normal.bf515d89.woff": {
    "file": "roboto-slab-greek-200-normal.bf515d89.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-vietnamese-200-normal.d35d2a72.woff": {
    "file": "roboto-slab-vietnamese-200-normal.d35d2a72.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-ext-200-normal.9fcc3aa5.woff2": {
    "file": "roboto-slab-latin-ext-200-normal.9fcc3aa5.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-ext-200-normal.a41c6b9b.woff": {
    "file": "roboto-slab-latin-ext-200-normal.a41c6b9b.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-200-normal.a13f9df7.woff2": {
    "file": "roboto-slab-latin-200-normal.a13f9df7.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-200-normal.78146ad8.woff": {
    "file": "roboto-slab-latin-200-normal.78146ad8.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-cyrillic-ext-300-normal.d14bf70a.woff2": {
    "file": "roboto-slab-cyrillic-ext-300-normal.d14bf70a.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-ext-300-normal.8d4b98c0.woff": {
    "file": "roboto-slab-cyrillic-ext-300-normal.8d4b98c0.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-cyrillic-300-normal.cfc1dfa2.woff2": {
    "file": "roboto-slab-cyrillic-300-normal.cfc1dfa2.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-300-normal.f0500af0.woff": {
    "file": "roboto-slab-cyrillic-300-normal.f0500af0.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-greek-300-normal.ae4340bf.woff2": {
    "file": "roboto-slab-greek-300-normal.ae4340bf.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-greek-300-normal.9c41a862.woff": {
    "file": "roboto-slab-greek-300-normal.9c41a862.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-vietnamese-300-normal.3693aa95.woff": {
    "file": "roboto-slab-vietnamese-300-normal.3693aa95.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-ext-300-normal.0bb1b214.woff2": {
    "file": "roboto-slab-latin-ext-300-normal.0bb1b214.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-ext-300-normal.615e8295.woff": {
    "file": "roboto-slab-latin-ext-300-normal.615e8295.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-300-normal.deaa5eca.woff2": {
    "file": "roboto-slab-latin-300-normal.deaa5eca.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-300-normal.6dd87d27.woff": {
    "file": "roboto-slab-latin-300-normal.6dd87d27.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-cyrillic-ext-400-normal.74e54082.woff2": {
    "file": "roboto-slab-cyrillic-ext-400-normal.74e54082.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-ext-400-normal.c250e40d.woff": {
    "file": "roboto-slab-cyrillic-ext-400-normal.c250e40d.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-cyrillic-400-normal.42aa362d.woff2": {
    "file": "roboto-slab-cyrillic-400-normal.42aa362d.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-400-normal.48500c8f.woff": {
    "file": "roboto-slab-cyrillic-400-normal.48500c8f.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-greek-400-normal.df102cdd.woff2": {
    "file": "roboto-slab-greek-400-normal.df102cdd.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-greek-400-normal.1e4355f9.woff": {
    "file": "roboto-slab-greek-400-normal.1e4355f9.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-vietnamese-400-normal.00b055dc.woff": {
    "file": "roboto-slab-vietnamese-400-normal.00b055dc.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-ext-400-normal.befc8883.woff2": {
    "file": "roboto-slab-latin-ext-400-normal.befc8883.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-ext-400-normal.c8bafe5f.woff": {
    "file": "roboto-slab-latin-ext-400-normal.c8bafe5f.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-400-normal.e3b93a1b.woff2": {
    "file": "roboto-slab-latin-400-normal.e3b93a1b.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-400-normal.a5a377de.woff": {
    "file": "roboto-slab-latin-400-normal.a5a377de.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-cyrillic-ext-500-normal.5ea4d794.woff2": {
    "file": "roboto-slab-cyrillic-ext-500-normal.5ea4d794.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-ext-500-normal.8d476a02.woff": {
    "file": "roboto-slab-cyrillic-ext-500-normal.8d476a02.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-cyrillic-500-normal.fd7f4d48.woff2": {
    "file": "roboto-slab-cyrillic-500-normal.fd7f4d48.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-500-normal.34c3311c.woff": {
    "file": "roboto-slab-cyrillic-500-normal.34c3311c.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-greek-500-normal.bf7622b6.woff2": {
    "file": "roboto-slab-greek-500-normal.bf7622b6.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-greek-500-normal.c9a3f4d8.woff": {
    "file": "roboto-slab-greek-500-normal.c9a3f4d8.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-vietnamese-500-normal.6763c1b9.woff": {
    "file": "roboto-slab-vietnamese-500-normal.6763c1b9.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-ext-500-normal.da7c260f.woff2": {
    "file": "roboto-slab-latin-ext-500-normal.da7c260f.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-ext-500-normal.1c495911.woff": {
    "file": "roboto-slab-latin-ext-500-normal.1c495911.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-500-normal.c6e91c8c.woff2": {
    "file": "roboto-slab-latin-500-normal.c6e91c8c.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-500-normal.b306c48a.woff": {
    "file": "roboto-slab-latin-500-normal.b306c48a.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-cyrillic-ext-600-normal.8a7d145f.woff2": {
    "file": "roboto-slab-cyrillic-ext-600-normal.8a7d145f.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-ext-600-normal.0aaac7ce.woff": {
    "file": "roboto-slab-cyrillic-ext-600-normal.0aaac7ce.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-cyrillic-600-normal.a903a5ae.woff2": {
    "file": "roboto-slab-cyrillic-600-normal.a903a5ae.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-600-normal.32f4dca6.woff": {
    "file": "roboto-slab-cyrillic-600-normal.32f4dca6.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-greek-600-normal.962dc948.woff2": {
    "file": "roboto-slab-greek-600-normal.962dc948.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-greek-600-normal.7e321e5b.woff": {
    "file": "roboto-slab-greek-600-normal.7e321e5b.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-vietnamese-600-normal.641fd082.woff": {
    "file": "roboto-slab-vietnamese-600-normal.641fd082.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-ext-600-normal.28e02f06.woff2": {
    "file": "roboto-slab-latin-ext-600-normal.28e02f06.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-ext-600-normal.1ab27ab3.woff": {
    "file": "roboto-slab-latin-ext-600-normal.1ab27ab3.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-600-normal.f6b0025a.woff2": {
    "file": "roboto-slab-latin-600-normal.f6b0025a.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-600-normal.9ff01a0a.woff": {
    "file": "roboto-slab-latin-600-normal.9ff01a0a.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-cyrillic-ext-700-normal.9b276e65.woff2": {
    "file": "roboto-slab-cyrillic-ext-700-normal.9b276e65.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-ext-700-normal.8a6a5661.woff": {
    "file": "roboto-slab-cyrillic-ext-700-normal.8a6a5661.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-cyrillic-700-normal.36713511.woff2": {
    "file": "roboto-slab-cyrillic-700-normal.36713511.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-700-normal.e735a264.woff": {
    "file": "roboto-slab-cyrillic-700-normal.e735a264.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-greek-700-normal.e19b129f.woff2": {
    "file": "roboto-slab-greek-700-normal.e19b129f.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-greek-700-normal.b7ecff05.woff": {
    "file": "roboto-slab-greek-700-normal.b7ecff05.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-vietnamese-700-normal.4a05efcc.woff": {
    "file": "roboto-slab-vietnamese-700-normal.4a05efcc.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-ext-700-normal.03ee983f.woff2": {
    "file": "roboto-slab-latin-ext-700-normal.03ee983f.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-ext-700-normal.ee76cba0.woff": {
    "file": "roboto-slab-latin-ext-700-normal.ee76cba0.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-700-normal.084c044e.woff2": {
    "file": "roboto-slab-latin-700-normal.084c044e.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-700-normal.6e5a88ee.woff": {
    "file": "roboto-slab-latin-700-normal.6e5a88ee.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-cyrillic-ext-800-normal.9cbc0ba0.woff2": {
    "file": "roboto-slab-cyrillic-ext-800-normal.9cbc0ba0.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-ext-800-normal.b5da902a.woff": {
    "file": "roboto-slab-cyrillic-ext-800-normal.b5da902a.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-cyrillic-800-normal.dbbcf182.woff2": {
    "file": "roboto-slab-cyrillic-800-normal.dbbcf182.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-800-normal.f50cc6dd.woff": {
    "file": "roboto-slab-cyrillic-800-normal.f50cc6dd.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-greek-800-normal.9a482692.woff2": {
    "file": "roboto-slab-greek-800-normal.9a482692.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-greek-800-normal.a4cd9f84.woff": {
    "file": "roboto-slab-greek-800-normal.a4cd9f84.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-vietnamese-800-normal.1250ab68.woff": {
    "file": "roboto-slab-vietnamese-800-normal.1250ab68.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-ext-800-normal.4d7ba76c.woff2": {
    "file": "roboto-slab-latin-ext-800-normal.4d7ba76c.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-ext-800-normal.675f48ba.woff": {
    "file": "roboto-slab-latin-ext-800-normal.675f48ba.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-800-normal.456a3936.woff2": {
    "file": "roboto-slab-latin-800-normal.456a3936.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-800-normal.ba159e07.woff": {
    "file": "roboto-slab-latin-800-normal.ba159e07.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-cyrillic-ext-900-normal.0d671900.woff2": {
    "file": "roboto-slab-cyrillic-ext-900-normal.0d671900.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-ext-900-normal.5a22120a.woff": {
    "file": "roboto-slab-cyrillic-ext-900-normal.5a22120a.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-cyrillic-900-normal.e45320b7.woff2": {
    "file": "roboto-slab-cyrillic-900-normal.e45320b7.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-cyrillic-900-normal.e3e9e1a5.woff": {
    "file": "roboto-slab-cyrillic-900-normal.e3e9e1a5.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-greek-900-normal.5191456f.woff2": {
    "file": "roboto-slab-greek-900-normal.5191456f.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-greek-900-normal.b326ae79.woff": {
    "file": "roboto-slab-greek-900-normal.b326ae79.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-vietnamese-900-normal.570ce4f2.woff": {
    "file": "roboto-slab-vietnamese-900-normal.570ce4f2.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-ext-900-normal.37bbacd9.woff2": {
    "file": "roboto-slab-latin-ext-900-normal.37bbacd9.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-ext-900-normal.6392b1e5.woff": {
    "file": "roboto-slab-latin-ext-900-normal.6392b1e5.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-slab-latin-900-normal.55e1d740.woff2": {
    "file": "roboto-slab-latin-900-normal.55e1d740.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-slab-latin-900-normal.32a00763.woff": {
    "file": "roboto-slab-latin-900-normal.32a00763.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-cyrillic-ext-100-normal.8e48cf20.woff2": {
    "file": "roboto-cyrillic-ext-100-normal.8e48cf20.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-cyrillic-ext-100-normal.4037eed1.woff": {
    "file": "roboto-cyrillic-ext-100-normal.4037eed1.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-cyrillic-100-normal.638764dc.woff2": {
    "file": "roboto-cyrillic-100-normal.638764dc.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-cyrillic-100-normal.c66effb1.woff": {
    "file": "roboto-cyrillic-100-normal.c66effb1.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-greek-100-normal.8c3798e3.woff2": {
    "file": "roboto-greek-100-normal.8c3798e3.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-greek-100-normal.a4022948.woff": {
    "file": "roboto-greek-100-normal.a4022948.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-vietnamese-100-normal.ca7eea0c.woff2": {
    "file": "roboto-vietnamese-100-normal.ca7eea0c.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-vietnamese-100-normal.900bd675.woff": {
    "file": "roboto-vietnamese-100-normal.900bd675.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-latin-ext-100-normal.10b31f4c.woff2": {
    "file": "roboto-latin-ext-100-normal.10b31f4c.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-latin-ext-100-normal.ceee6016.woff": {
    "file": "roboto-latin-ext-100-normal.ceee6016.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-latin-100-normal.0f303f31.woff2": {
    "file": "roboto-latin-100-normal.0f303f31.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-latin-100-normal.090d448c.woff": {
    "file": "roboto-latin-100-normal.090d448c.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-cyrillic-ext-300-normal.435e4b7f.woff2": {
    "file": "roboto-cyrillic-ext-300-normal.435e4b7f.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-cyrillic-ext-300-normal.5e06c977.woff": {
    "file": "roboto-cyrillic-ext-300-normal.5e06c977.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-cyrillic-300-normal.47aa3bfa.woff2": {
    "file": "roboto-cyrillic-300-normal.47aa3bfa.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-cyrillic-300-normal.c07952fe.woff": {
    "file": "roboto-cyrillic-300-normal.c07952fe.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-greek-300-normal.455c2c1a.woff2": {
    "file": "roboto-greek-300-normal.455c2c1a.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-greek-300-normal.6bb1ef10.woff": {
    "file": "roboto-greek-300-normal.6bb1ef10.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-vietnamese-300-normal.51f3f418.woff2": {
    "file": "roboto-vietnamese-300-normal.51f3f418.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-vietnamese-300-normal.7747ef64.woff": {
    "file": "roboto-vietnamese-300-normal.7747ef64.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-latin-ext-300-normal.b076e863.woff2": {
    "file": "roboto-latin-ext-300-normal.b076e863.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-latin-ext-300-normal.35da7ccd.woff": {
    "file": "roboto-latin-ext-300-normal.35da7ccd.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-latin-300-normal.f7591131.woff2": {
    "file": "roboto-latin-300-normal.f7591131.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-latin-300-normal.ddb5c61d.woff": {
    "file": "roboto-latin-300-normal.ddb5c61d.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-cyrillic-ext-400-normal.b7ef2cd1.woff2": {
    "file": "roboto-cyrillic-ext-400-normal.b7ef2cd1.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-cyrillic-ext-400-normal.0a32035a.woff": {
    "file": "roboto-cyrillic-ext-400-normal.0a32035a.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-cyrillic-400-normal.495d38d4.woff2": {
    "file": "roboto-cyrillic-400-normal.495d38d4.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-cyrillic-400-normal.adba67d2.woff": {
    "file": "roboto-cyrillic-400-normal.adba67d2.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-greek-400-normal.daf51ab5.woff2": {
    "file": "roboto-greek-400-normal.daf51ab5.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-greek-400-normal.076b9dc1.woff": {
    "file": "roboto-greek-400-normal.076b9dc1.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-vietnamese-400-normal.77b24796.woff2": {
    "file": "roboto-vietnamese-400-normal.77b24796.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-vietnamese-400-normal.d2390f1a.woff": {
    "file": "roboto-vietnamese-400-normal.d2390f1a.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-latin-ext-400-normal.3c23eb02.woff2": {
    "file": "roboto-latin-ext-400-normal.3c23eb02.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-latin-ext-400-normal.c2b94086.woff": {
    "file": "roboto-latin-ext-400-normal.c2b94086.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-latin-400-normal.f6734f81.woff2": {
    "file": "roboto-latin-400-normal.f6734f81.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-latin-400-normal.a9fdbefa.woff": {
    "file": "roboto-latin-400-normal.a9fdbefa.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-cyrillic-ext-500-normal.aeed0e51.woff2": {
    "file": "roboto-cyrillic-ext-500-normal.aeed0e51.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-cyrillic-ext-500-normal.57138788.woff": {
    "file": "roboto-cyrillic-ext-500-normal.57138788.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-cyrillic-500-normal.3728fbdd.woff2": {
    "file": "roboto-cyrillic-500-normal.3728fbdd.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-cyrillic-500-normal.4bc088e9.woff": {
    "file": "roboto-cyrillic-500-normal.4bc088e9.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-greek-500-normal.713780d8.woff2": {
    "file": "roboto-greek-500-normal.713780d8.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-greek-500-normal.93181eb7.woff": {
    "file": "roboto-greek-500-normal.93181eb7.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-vietnamese-500-normal.0948409a.woff2": {
    "file": "roboto-vietnamese-500-normal.0948409a.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-vietnamese-500-normal.7899e6a5.woff": {
    "file": "roboto-vietnamese-500-normal.7899e6a5.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-latin-ext-500-normal.7f1c829b.woff2": {
    "file": "roboto-latin-ext-500-normal.7f1c829b.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-latin-ext-500-normal.a303676a.woff": {
    "file": "roboto-latin-ext-500-normal.a303676a.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-latin-500-normal.b0195382.woff2": {
    "file": "roboto-latin-500-normal.b0195382.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-latin-500-normal.3ac31048.woff": {
    "file": "roboto-latin-500-normal.3ac31048.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-cyrillic-ext-700-normal.3c505383.woff2": {
    "file": "roboto-cyrillic-ext-700-normal.3c505383.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-cyrillic-ext-700-normal.8ea7934f.woff": {
    "file": "roboto-cyrillic-ext-700-normal.8ea7934f.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-cyrillic-700-normal.6a84eeee.woff2": {
    "file": "roboto-cyrillic-700-normal.6a84eeee.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-cyrillic-700-normal.6f82c5e2.woff": {
    "file": "roboto-cyrillic-700-normal.6f82c5e2.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-greek-700-normal.1c9cc76f.woff2": {
    "file": "roboto-greek-700-normal.1c9cc76f.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-greek-700-normal.3f1a5012.woff": {
    "file": "roboto-greek-700-normal.3f1a5012.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-vietnamese-700-normal.4ec57f2a.woff2": {
    "file": "roboto-vietnamese-700-normal.4ec57f2a.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-vietnamese-700-normal.d986b503.woff": {
    "file": "roboto-vietnamese-700-normal.d986b503.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-latin-ext-700-normal.fc66f942.woff2": {
    "file": "roboto-latin-ext-700-normal.fc66f942.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-latin-ext-700-normal.3d1cbacf.woff": {
    "file": "roboto-latin-ext-700-normal.3d1cbacf.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-latin-700-normal.f5aebdfe.woff2": {
    "file": "roboto-latin-700-normal.f5aebdfe.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-latin-700-normal.d89bc0fc.woff": {
    "file": "roboto-latin-700-normal.d89bc0fc.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-cyrillic-ext-900-normal.f265cee6.woff2": {
    "file": "roboto-cyrillic-ext-900-normal.f265cee6.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-cyrillic-ext-900-normal.8d3d12a5.woff": {
    "file": "roboto-cyrillic-ext-900-normal.8d3d12a5.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-cyrillic-900-normal.9fdb12ce.woff2": {
    "file": "roboto-cyrillic-900-normal.9fdb12ce.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-cyrillic-900-normal.c917b854.woff": {
    "file": "roboto-cyrillic-900-normal.c917b854.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-greek-900-normal.2550c2e2.woff2": {
    "file": "roboto-greek-900-normal.2550c2e2.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-greek-900-normal.8615b4aa.woff": {
    "file": "roboto-greek-900-normal.8615b4aa.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-vietnamese-900-normal.3a38c967.woff2": {
    "file": "roboto-vietnamese-900-normal.3a38c967.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-vietnamese-900-normal.337a94bc.woff": {
    "file": "roboto-vietnamese-900-normal.337a94bc.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-latin-ext-900-normal.2781e9e7.woff2": {
    "file": "roboto-latin-ext-900-normal.2781e9e7.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-latin-ext-900-normal.45d477a3.woff": {
    "file": "roboto-latin-ext-900-normal.45d477a3.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "roboto-latin-900-normal.7e262106.woff2": {
    "file": "roboto-latin-900-normal.7e262106.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "roboto-latin-900-normal.730f633f.woff": {
    "file": "roboto-latin-900-normal.730f633f.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "pages/auth/reset.vue": {
    "resourceType": "script",
    "module": true,
    "file": "reset.300ea023.js",
    "imports": [
      "_form.3809ebd5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_useTranslate.d7d7ebb3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/auth/reset.vue"
  },
  "pages/auth/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "file": "sign-in.db311f31.js",
    "imports": [
      "_form.3809ebd5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_useTranslate.d7d7ebb3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/auth/sign-in.vue"
  },
  "pages/auth/sign-up.vue": {
    "resourceType": "script",
    "module": true,
    "file": "sign-up.ffc271bd.js",
    "imports": [
      "_form.3809ebd5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_useTranslate.d7d7ebb3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/auth/sign-up.vue"
  },
  "pages/dash.css": {
    "resourceType": "style",
    "file": "dash.c122e14b.css",
    "src": "pages/dash.css"
  },
  "pages/dash.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "castor.f4af3c0a.jpg"
    ],
    "css": [],
    "file": "dash.e56f3e83.js",
    "imports": [
      "_hamburger-menu-button.1e2d10f9.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/dash.vue"
  },
  "dash.c122e14b.css": {
    "file": "dash.c122e14b.css",
    "resourceType": "style"
  },
  "castor.f4af3c0a.jpg": {
    "file": "castor.f4af3c0a.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "pages/dash/deal-editor.vue": {
    "resourceType": "script",
    "module": true,
    "file": "deal-editor.29354624.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/dash/deal-editor.vue"
  },
  "pages/dash/overview.vue": {
    "resourceType": "script",
    "module": true,
    "file": "overview.bae21691.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/dash/overview.vue"
  },
  "pages/dev.vue": {
    "resourceType": "script",
    "module": true,
    "file": "dev.518f4c4d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/dev.vue"
  },
  "pages/dev/db-schema.css": {
    "resourceType": "style",
    "file": "db-schema.b26d4e85.css",
    "src": "pages/dev/db-schema.css"
  },
  "pages/dev/db-schema.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "db-schema.3fee119b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/dev/db-schema.vue"
  },
  "db-schema.b26d4e85.css": {
    "file": "db-schema.b26d4e85.css",
    "resourceType": "style"
  },
  "pages/dev/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.784ca9b5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/dev/index.vue"
  },
  "pages/download.vue": {
    "resourceType": "script",
    "module": true,
    "file": "download.20e7205f.js",
    "imports": [
      "_lang-switcher.712b1654.js",
      "_nuxt-link.3fbcb472.js",
      "_card-page-layout.87c377d5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useTranslate.d7d7ebb3.js",
      "_hamburger-menu-button.1e2d10f9.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/download.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.fc1daae4.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "shortIntro-compressed.e6839cd4.mp4",
      "shortIntroLastFrame.f94ad735.jpg",
      "castor-square.6080d437.jpg"
    ],
    "css": [],
    "file": "index.439a3a51.js",
    "imports": [
      "_card-page-layout.87c377d5.js",
      "_nuxt-link.3fbcb472.js",
      "_lang-switcher.712b1654.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_hamburger-menu-button.1e2d10f9.js",
      "_useTranslate.d7d7ebb3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.fc1daae4.css": {
    "file": "index.fc1daae4.css",
    "resourceType": "style"
  },
  "shortIntro-compressed.e6839cd4.mp4": {
    "file": "shortIntro-compressed.e6839cd4.mp4",
    "resourceType": "video"
  },
  "shortIntroLastFrame.f94ad735.jpg": {
    "file": "shortIntroLastFrame.f94ad735.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "castor-square.6080d437.jpg": {
    "file": "castor-square.6080d437.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "pages/policy/copyright.vue": {
    "resourceType": "script",
    "module": true,
    "file": "copyright.67541081.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/policy/copyright.vue"
  },
  "pages/policy/disclaimer.vue": {
    "resourceType": "script",
    "module": true,
    "file": "disclaimer.88f07ac0.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/policy/disclaimer.vue"
  },
  "pages/policy/index.css": {
    "resourceType": "style",
    "file": "index.49ec1ea0.css",
    "src": "pages/policy/index.css"
  },
  "pages/policy/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "index.e48b8c70.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/policy/index.vue"
  },
  "index.49ec1ea0.css": {
    "file": "index.49ec1ea0.css",
    "resourceType": "style"
  },
  "pages/policy/privacy.vue": {
    "resourceType": "script",
    "module": true,
    "file": "privacy.2c9bd0f6.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/policy/privacy.vue"
  },
  "pages/policy/terms.vue": {
    "resourceType": "script",
    "module": true,
    "file": "terms.8ee56dff.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/policy/terms.vue"
  },
  "pages/test-card-page-layout.vue": {
    "resourceType": "script",
    "module": true,
    "file": "test-card-page-layout.ffd5fee0.js",
    "imports": [
      "_card-page-layout.87c377d5.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.3fbcb472.js",
      "_hamburger-menu-button.1e2d10f9.js",
      "_useTranslate.d7d7ebb3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/test-card-page-layout.vue"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
