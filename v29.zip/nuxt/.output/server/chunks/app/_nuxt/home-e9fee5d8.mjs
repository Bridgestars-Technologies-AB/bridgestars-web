const button = "Begin now";
const revolutionize = {
  title: "Revolutionizing the Bridge Learning Experience",
  desc1: "With Bridgestars, we aim to strengthen the existing bridge education by replacing obsolete IT-solutions with modern and user-friendly software."
};
const quote = {
  desc1: "In a world of rapid technological advancements, the world of bridge has not been able to keep up. We are two students who have noticed a need for a clean  and modern solution for playing bridge online that is fun, easy and engaging. Since 2020 we have developed the online platform Bridgestars which focuses on the educational aspects of bridge. Brigestars let students from Swedish bridge schools improve their skills by taking part in different courses available on the platform. Our vision is to provide an engaging learning environment for all bridge students, wether you're a beginner or an experienced player. ",
  castor: "Bridgestars CEO, Founder and Junior World Champion 2018."
};
const contact = {
  title1: "Contact Us",
  title2: "Interested in a partnership?",
  desc1: "We are always looking for new partners to create better learning environments for bridge students. Are you a bridge teacher aiming to improve your students' experiences? Please reach out to us on {email}, we are looking forward to hearing from you.",
  emailSubject: "Expression of Interest",
  emailBody: "Hi Bridgestars,%0D%0AI am interested in collaborating with you and would like to know more about how we can help each other.%0D%0A%0D%0AMy name is:%0D%0A%0D%0ABridge Club:%0D%0A%0D%0AI am interested in Bridgestars related to: education/custom IT solutions/Online bridge/others"
};
const home = {
  button,
  revolutionize,
  quote,
  contact
};

export { button, contact, home as default, quote, revolutionize };
//# sourceMappingURL=home-e9fee5d8.mjs.map
