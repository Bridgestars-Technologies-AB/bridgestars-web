const Policy_vue_vue_type_style_index_0_scoped_80ddcaac_lang = ".policyButton[data-v-80ddcaac]{flex:1 1 auto;margin:0;padding:0}.policyButton[data-v-80ddcaac]:focus{--tw-bg-opacity:1;--tw-text-opacity:1;background-color:rgb(255 255 255/var(--tw-bg-opacity));border-radius:.5rem;color:rgb(58 76 107/var(--tw-text-opacity))}.zoomIn[data-v-80ddcaac]{animation:anim-zoom-80ddcaac .5s ease-in-out 0ms}@keyframes anim-zoom-80ddcaac{0%{opacity:0;transform:scaleY(.8) scaleX(.3) translateY(-40px)}to{opacity:1;transform:scale(1) translateY(0)}}";

const indexStyles_9f6638d6 = [Policy_vue_vue_type_style_index_0_scoped_80ddcaac_lang];

export { indexStyles_9f6638d6 as default };
//# sourceMappingURL=index-styles.9f6638d6.mjs.map
