const mac = {
  title: "Bridgestars till Mac OS (.app)",
  description: "Denna programvara \xE4r till Mac OS (Apple). N\xE4r du startar den f\xF6r f\xF6rsta g\xE5ngen kommer den fr\xE5ga om du vill ha en genv\xE4g p\xE5 skrivbordet."
};
const win = {
  title: "Bridgestars till Windows (.exe)",
  description: "Denna programvara \xE4r till Windows (PC). N\xE4r du har laddat ner den, starta applikationen direkt fr\xE5n dina nedladdningar s\xE5 kommer en genv\xE4g att skapas p\xE5 hemsk\xE4rmen."
};
const title = "V\xE4lkommen till Bridgestars!";
const desc1 = "Bridgestars finns nu tillg\xE4ngligt f\xF6r n\xE5gra utvalda medlemmar. F\xF6r att komma ig\xE5ng, ladda ner programvaran nedan p\xE5 din station\xE4ra eller b\xE4rbara dator s\xE5 kommer vi guida dig igenom processen att b\xF6rja anv\xE4nda Bridgestars.";
const desc2 = "Vi uppskattar all positiv och negativ \xE5terkoppling om v\xE5rt program. Vi tar g\xE4rna emot kommentarer via {discord} eller {email} om du st\xF6ter p\xE5 n\xE5gra problem. Du \xE4r ocks\xE5 v\xE4lkommen att f\xF6resl\xE5 nya funktioner.";
const desc3 = "Programmet kr\xE4ver som mest 1 GB utrymme.";
const desc4 = "";
const download = "Ladda ner";
const size = "Storlek ({{size}})";
const isMobile = "Vi jobbar p\xE5 att g\xF6ra Bridgestars tillg\xE4ngligt p\xE5 din mobila enhet. S\xE5 l\xE4nge, g\xE5 in fr\xE5n din dator ist\xE4llet!";
const isOtherOS = "Vi jobbar p\xE5 att g\xF6ra Bridgestars tillg\xE4ngligt p\xE5 din enhet. S\xE5 l\xE4nge, g\xE5 in fr\xE5n din Windows- eller Macdator ist\xE4llet!";
const showOptions = "Visa alla nedladdningsalternativ";
const download$1 = {
  mac,
  win,
  title,
  desc1,
  desc2,
  desc3,
  desc4,
  download,
  size,
  isMobile,
  isOtherOS,
  showOptions
};

export { download$1 as default, desc1, desc2, desc3, desc4, download, isMobile, isOtherOS, mac, showOptions, size, title, win };
//# sourceMappingURL=download-28296e62.mjs.map
