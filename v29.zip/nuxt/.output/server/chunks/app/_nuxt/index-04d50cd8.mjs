import { useSSRContext, resolveComponent, mergeProps } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';

const _sfc_main$1 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  const _component_Terms = resolveComponent("Terms");
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-screen h-screen opacity-100 fixed bg-[#C0C0C0]" }, _attrs))} data-v-80ddcaac><header class="policyHeader w-screen h-[70px] mt-[30px] mb-[30px] bg-[#FFFFFF]" data-v-80ddcaac><button class="zoomIn text-[#3F516F] text-opacity-100 font-black" data-v-80ddcaac> Bridgestars </button><div class="px-[30px] flex flex-row justify-end gap-[60px]" data-v-80ddcaac><button class="zoomIn" data-v-80ddcaac>Home</button><button class="zoomIn" data-v-80ddcaac>About Us</button><button class="zoomIn" data-v-80ddcaac>Sign In</button></div></header><div class="navigateBar bg-[#E0E0E0] rounded-lg h-[50px] mx-[52px] flex flex-row justify-center" data-v-80ddcaac><button class="policyButton zoomIn" data-v-80ddcaac>Terms</button><button class="policyButton zoomIn" data-v-80ddcaac>Privacy</button><button class="policyButton zoomIn" data-v-80ddcaac>Disclaimer</button><button class="policyButton zoomIn" data-v-80ddcaac>Copyright</button></div><div class="w-[100 %] h-[100%] flex flex-row justify-center content-center mt-[40px]" data-v-80ddcaac><div id="policyBox" class="bg-[#FFFFFF] w-[100%] ml-[70px] mr-[70px] overflow-auto" data-v-80ddcaac>`);
  _push(ssrRenderComponent(_component_Terms, null, null, _parent));
  _push(`</div></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/policy/Policy.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender$1], ["__scopeId", "data-v-80ddcaac"]]);
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_Policy = __nuxt_component_0;
  _push(ssrRenderComponent(_component_Policy, _attrs, null, _parent));
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/policy/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { index as default };
//# sourceMappingURL=index-04d50cd8.mjs.map
