import { ssrRenderAttrs, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { useSSRContext } from 'vue';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const routes = [
      { path: "/dev/db-schema", name: "Database Classes and Fields" }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="flex flex-col items-center text-center mt-5"><h1 class="text-3xl font-bold">Bridgestars Dev Reference</h1><p class="text1 font-family2 text-2xl">Here are some documentation on basic features in the Bridgestars stack</p></div><div class="mx-9 my-9 flex flex-wrap flex-col"><!--[-->`);
      ssrRenderList(routes, (route) => {
        _push(`<div><div class="w-full cursor-pointer flex items-center justify-center"><a class="xs:text-[14px] md:text-[20px] text-blue font-family2 mr-1">${ssrInterpolate(route.name)}</a><span class="i-material-symbols-arrow-forward-ios text-blue xs:text-[14px] md:text-[20px]"></span></div></div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/dev/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-9a346849.mjs.map
