const dbSchema_vue_vue_type_style_index_0_scoped_8d0f4d08_lang = "th[data-v-8d0f4d08]{--tw-text-opacity:1;color:rgb(52 71 103/var(--tw-text-opacity));font-family:Roboto Slab,sans-serif;text-align:left}@media (min-width:0px){th[data-v-8d0f4d08]{font-size:8px}}@media (min-width:576px){th[data-v-8d0f4d08]{font-size:16px}}@media (min-width:1200px){th[data-v-8d0f4d08]{font-size:20px}}td[data-v-8d0f4d08]{--tw-text-opacity:1;color:rgb(52 71 103/var(--tw-text-opacity));font-family:Roboto Slab,sans-serif;font-weight:300;padding-left:.25rem;padding-right:.25rem}@media (min-width:0px){td[data-v-8d0f4d08]{font-size:6px}}@media (min-width:576px){td[data-v-8d0f4d08]{font-size:16px}}@media (min-width:1200px){td[data-v-8d0f4d08]{font-size:18px}}td[data-v-8d0f4d08]{border-bottom:1px solid #e5e5e5;border-top:1px solid #e5e5e5}table[data-v-8d0f4d08]{word-wrap:break-word}";

const dbSchemaStyles_fcedc1c7 = [dbSchema_vue_vue_type_style_index_0_scoped_8d0f4d08_lang, dbSchema_vue_vue_type_style_index_0_scoped_8d0f4d08_lang];

export { dbSchemaStyles_fcedc1c7 as default };
//# sourceMappingURL=db-schema-styles.fcedc1c7.mjs.map
