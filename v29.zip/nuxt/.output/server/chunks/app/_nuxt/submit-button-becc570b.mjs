import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { useSSRContext, defineComponent, mergeProps, ref, unref, createElementBlock } from 'vue';
import { a as useRouter } from '../server.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderAttr, ssrRenderSlot, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';

const _imports_0 = "" + buildAssetsURL("auth-form-suits.fbea51fd.svg");
const _imports_1 = "" + buildAssetsURL("auth-form-ipad.2b33d4ce.svg");
const _imports_2 = "" + buildAssetsURL("sign_in.1171b396.svg");
const _imports_3 = "" + buildAssetsURL("logo-trans-512px.6894ce8f.png");
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "form",
  __ssrInlineRender: true,
  props: ["header", "title", "subtitle", "footer"],
  emits: ["submit"],
  setup(__props, { emit }) {
    useRouter();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "fixed bottom-0 top-0 w-full h-full flex flex-col justify-center bg-[#fefefe]" }, _attrs))} data-v-60ccd3d8><div class="absolute top-0 flex justify-start whitespace-nowrap pt-[30px] pl-[30px]" data-v-60ccd3d8><button class="normal-case text-blue authHeader" data-v-60ccd3d8>${ssrInterpolate(_ctx.$t("auth:common.home"))}</button><span class="authHeader text-grey opacity-80 mx-2" data-v-60ccd3d8> / </span><span class="authHeader text-grey opacity-80" data-v-60ccd3d8>${ssrInterpolate(__props.header)}</span></div><div class="absolute flex justify-center items-center z-[-1] h-full w-full" data-v-60ccd3d8><img${ssrRenderAttr("src", _imports_0)} class="xs:block sm:hidden w-[100%] scale-[1] min-w-[600px]" data-v-60ccd3d8><img${ssrRenderAttr("src", _imports_1)} class="xs:hidden sm:block w-[100%] scale-[1] max-w-[1400px] min-w-[1085px]" data-v-60ccd3d8></div><form name="auth-form" class="flex flex-col grow items-center justify-center" data-v-60ccd3d8><img class="anim-bounce pt-[10px] w-[50%] h-[80%]" id="sign-in-image"${ssrRenderAttr("src", _imports_2)} alt="Bridgestars sign-in image" data-v-60ccd3d8><img class="anim-bounce w-[64px] h-[64px] xs:mt-0 sm:mt-5 mb-5"${ssrRenderAttr("src", _imports_3)} alt="Bridgestars logo" data-v-60ccd3d8><h6 class="zoomIn text-dark flex text-center text-opacity-100 font-bold mb-4 text-[19px] font-family2" data-v-60ccd3d8>${ssrInterpolate(__props.title)}</h6><span class="zoomIn text2 sm:mb-7 xs:mb-4 flex text-center text-[17px]" data-v-60ccd3d8>${ssrInterpolate(__props.subtitle)}</span><div class="zoomIn flex flex-col items-center sm:space-y-4 xs:space-y-3 xs:w-[80%] sm:w-[80%] md:w-[70%] lg:w-[70%] max-w-[400px]" data-v-60ccd3d8>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></form></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/auth/form.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-60ccd3d8"]]);
const __nuxt_component_0 = /* @__PURE__ */ defineComponent({
  name: "ClientOnly",
  inheritAttrs: false,
  // eslint-disable-next-line vue/require-prop-types
  props: ["fallback", "placeholder", "placeholderTag", "fallbackTag"],
  setup(_, { slots, attrs }) {
    const mounted = ref(false);
    return (props) => {
      var _a;
      if (mounted.value) {
        return (_a = slots.default) == null ? void 0 : _a.call(slots);
      }
      const slot = slots.fallback || slots.placeholder;
      if (slot) {
        return slot();
      }
      const fallbackStr = props.fallback || props.placeholder || "";
      const fallbackTag = props.fallbackTag || props.placeholderTag || "span";
      return createElementBlock(fallbackTag, attrs, fallbackStr);
    };
  }
});
const _sfc_main$1 = {
  __name: "input-field",
  __ssrInlineRender: true,
  props: [
    "placeholder",
    "id",
    "wrapperClass",
    "modelValue"
  ],
  emits: ["update:modelValue"],
  setup(__props) {
    ref(false);
    ref(false);
    const input = ref(null);
    const value = ref("");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "input-block " + __props.wrapperClass
      }, _attrs))} data-v-cd30f8a7><input${ssrRenderAttrs(mergeProps({ class: "py-2.5 px-3.5 bg-white" }, _ctx.$attrs, {
        placeholder: " ",
        ref_key: "input",
        ref: input,
        id: __props.id,
        value: __props.modelValue || unref(value)
      }))} data-v-cd30f8a7><span class="placeholder text2 !font-light !text-[14px] !tracking-[1.2px]" data-v-cd30f8a7>${ssrInterpolate(__props.placeholder)}</span><small class="info" data-v-cd30f8a7></small>`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/base/input-field.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-cd30f8a7"]]);
const _sfc_main = {
  __name: "submit-button",
  __ssrInlineRender: true,
  props: ["wrapperClass", "text"],
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "buttonDiv " + __props.wrapperClass
      }, _attrs))} data-v-cca54568><button${ssrRenderAttrs(mergeProps({ class: "font-family py-[12px] px-[28px] font-normal rounded-[8px] h-[42px] btn tracking-[2px]" }, _ctx.$attrs))} data-v-cca54568>${ssrInterpolate(__props.text || "SUBMIT")}</button></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/base/submit-button.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-cca54568"]]);

export { __nuxt_component_0$1 as _, __nuxt_component_1 as a, __nuxt_component_2 as b };
//# sourceMappingURL=submit-button-becc570b.mjs.map
