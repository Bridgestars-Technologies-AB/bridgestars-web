import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_1$2 } from './hamburger-menu-button-838d7b8a.mjs';
import { useSSRContext, inject, unref, withAsyncContext, ref, provide, mergeProps, computed } from 'vue';
import { ssrRenderComponent, ssrRenderClass, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrRenderAttrs } from 'vue/server-renderer';
import { f as defineStore, a as useRouter, d as useRoute, b as useToast, e as useAuth, l as loadTranslations, n as navigateTo, _ as __nuxt_component_0$1 } from '../server.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';
import 'unctx';
import 'vue-router';
import 'parse/dist/parse.min.js';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'cookie-es';
import 'pinia-plugin-persistedstate';
import 'i18next';
import 'i18next-vue';

const _sfc_main$3 = {
  __name: "side-menu-item",
  __ssrInlineRender: true,
  props: ["icon", "keypath", "selected", "enabled"],
  setup(__props) {
    const props = __props;
    const bgColor = computed(() => props.selected ? "bg-dash-accent-light" : "bg-dark dark:bg-light group-hover:bg-dash-accent");
    const textColor = computed(() => props.selected ? "text-dash-accent-light" : "text-dark dark:text-light group-hover:text-dash-accent");
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex items-center px-2 py-2 group hover:cursor-pointer" }, _attrs))}><div class="flex items-center"><span id="icon" class="${ssrRenderClass(`text-[24px] mr-[10px] group-hover:animate-shake ${__props.icon} ${unref(bgColor)}`)}"></span></div><span class="${ssrRenderClass(`font-family text-[14px] font-light tracking-wide ${__props.enabled ? "" : "line-through"} ${unref(textColor)}`)}">${ssrInterpolate(_ctx.$t(props.keypath))}</span></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/dash/side-menu-item.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_1$1 = _sfc_main$3;
const _imports_0 = "" + buildAssetsURL("castor.f4af3c0a.jpg");
const _sfc_main$2 = {
  __name: "side-menu",
  __ssrInlineRender: true,
  setup(__props) {
    const router = useRouter();
    const route = useRoute();
    const toast = useToast();
    const auth = useAuth();
    const items = [
      {
        name: "overview",
        icon: "i-ic-outline-home"
      },
      {
        divider: true,
        name: "analysis"
      },
      {
        name: "deal-editor",
        icon: "i-material-symbols-sports-esports-outline"
      },
      // {
      //   name: "dealhistory",
      //   icon:"i-material-symbols-history"
      // },
      {
        name: "contract-calc",
        icon: "i-material-symbols-score"
      },
      {
        name: "simulator",
        icon: "i-material-symbols-analytics"
      },
      {
        divider: true,
        name: "exercise"
      },
      {
        name: "contracting",
        icon: "i-material-symbols-sports-esports-outline"
      },
      {
        name: "gambit",
        icon: "i-material-symbols-play-circle-outline"
      },
      {
        name: "suit-treatments",
        icon: "i-material-symbols-hive"
      },
      {
        name: "play",
        icon: "i-material-symbols-play-circle-outline"
      },
      {
        divider: true,
        name: "other"
      },
      {
        name: "results",
        icon: "i-material-symbols-text-snippet"
      },
      {
        name: "help",
        icon: "i-material-symbols-info"
      },
      {
        name: "sign-out",
        icon: "i-tabler-logout-2",
        action: async () => {
          if (auth.authenticated)
            await auth.signOut();
          toast.clear();
          toast.success("You have been signed out.");
          navigateTo("/");
        }
      }
    ];
    items.map((x) => x.enabled = x.action || router.getRoutes().some((r) => r.name == "dash-" + x.name));
    const isOpen = inject("side-menu-open");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_base_hamburger_menu_button = __nuxt_component_1$2;
      const _component_dash_side_menu_item = __nuxt_component_1$1;
      _push(`<!--[-->`);
      if (!unref(isOpen)) {
        _push(`<div class="absolute" data-v-354a07a2>`);
        _push(ssrRenderComponent(_component_base_hamburger_menu_button, {
          onClick: ($event) => isOpen.value = !unref(isOpen),
          isOpen: unref(isOpen),
          class: "!scale-[0.3]",
          innerClass: "dark:bg-dash-light-300 bg-dark"
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div id="side-menu" class="${ssrRenderClass(`bg-dash-light-200 dark:bg-dash-dark-300 flex flex-col w-[270px] z-[10] ${unref(isOpen) ? "left-0" : "-left-[270px]"} h-[100%] overflow-y-auto fixed`)}" data-v-354a07a2><div class="sticky top-0 h-0 flex justify-end" data-v-354a07a2>`);
      _push(ssrRenderComponent(_component_base_hamburger_menu_button, {
        onClick: ($event) => isOpen.value = !unref(isOpen),
        isOpen: unref(isOpen),
        class: "!scale-[0.3]",
        innerClass: "dark:bg-dash-light-300 bg-dark"
      }, null, _parent));
      _push(`</div><div class="text-center flex items-center pl-4 pt-7 flex-wrap cursor-pointer" data-v-354a07a2><img class="object-cover object-top w-[50px] aspect-square rounded-full"${ssrRenderAttr("src", _imports_0)} data-v-354a07a2><div class="flex flex-col text-start pl-2 justify-center space-y-2" data-v-354a07a2><h3 class="text-[22px] leading-[22px] tracking-tighter" data-v-354a07a2>Castor Mann</h3><h6 class="text-[#14C6A4] dark:text-[#14C6a4] font-light tracking-normal" data-v-354a07a2>Bridgestars Premium</h6></div></div><div class="flex flex-col px-5 mt-6 mb-10" data-v-354a07a2><!--[-->`);
      ssrRenderList(items, (item) => {
        _push(`<div data-v-354a07a2>`);
        if (item.divider) {
          _push(`<div class="font-family font-light text-dark opacity-70 dark:text-light mb-1 mt-5 tracking-wide text-[16px]" data-v-354a07a2>${ssrInterpolate(_ctx.$t("dashboard:side_menu." + item.name))}</div>`);
        } else {
          _push(ssrRenderComponent(_component_dash_side_menu_item, {
            icon: item.icon,
            keypath: `dashboard:side_menu.${item.name}`,
            selected: unref(route).name == "dash-" + item.name,
            enabled: item.enabled
          }, null, _parent));
        }
        _push(`</div>`);
      });
      _push(`<!--]--></div></div><!--]-->`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/dash/side-menu.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-354a07a2"]]);
const useDarkMode = defineStore("darkmode", {
  state: () => ({ value: true, auto: false }),
  //fix auto-detect
  getters: {
    enabled: (state) => state.value
  },
  actions: {
    toggle() {
      this.value = !this.value;
    },
    set(value) {
      this.value = value;
    }
  },
  persist: true
});
const common = "w-[24px] h-[24px] hover:bg-dash-accent dark:hover:bg-dash-accent hover:animate-shake ";
const _sfc_main$1 = {
  __name: "top-menu",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const darkMode = useDarkMode();
    const notificationsOpen = ref(false);
    const isSelected = (item) => route.name == "dash-" + item;
    const colored = (b) => b ? common + "bg-dash-accent dark:bg-dash-accent" : common + "bg-dark dark:bg-light";
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="bg-dash-light-300 dark:bg-dash-dark flex justify-end flex-grow p-3 space-x-4 h-fit"><span class="${ssrRenderClass(`${!unref(darkMode).enabled ? "i-material-symbols-dark-mode-outline" : "i-material-symbols-light-mode-outline"}  ${colored(false)}`)}"></span><span class="${ssrRenderClass(`i-material-symbols-notifications-outline ${colored(
        unref(notificationsOpen)
      )}`)}" id="popover-target"></span><span class="${ssrRenderClass(`i-material-symbols-settings-outline ${colored(
        isSelected("settings")
      )}`)}"></span><span class="${ssrRenderClass(`i-ic-baseline-account-circle ${colored(isSelected("profile"))}`)}"></span></div><button id="popoverButton" type="button" class="text-white bg-info hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Default popover</button><div data-popover id="popoverContent" role="tooltip" class="absolute z-10 invisible inline-block w-64 text-sm text-gray-500 transition-opacity duration-300 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 dark:text-gray-400 dark:border-gray-600 dark:bg-gray-800"><div class="px-3 py-2 bg-gray-100 border-b border-gray-200 rounded-t-lg dark:border-gray-600 dark:bg-gray-700"><h3 class="font-semibold text-gray-900 dark:text-white">Popover title</h3></div><div class="px-3 py-2"><p>And here&#39;s some amazing content. It&#39;s very engaging. Right?</p></div><div data-popper-arrow></div></div><!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/dash/top-menu.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$1;
const _sfc_main = {
  __name: "dash",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    [__temp, __restore] = withAsyncContext(() => loadTranslations("dashboard")), await __temp, __restore();
    const route = useRoute();
    if (route.name === "dash") {
      useRouter().replace("dash/overview");
    }
    const darkMode = useDarkMode();
    const sideMenuOpen = ref(true);
    provide("side-menu-open", sideMenuOpen);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_dash_side_menu = __nuxt_component_0;
      const _component_dash_top_menu = __nuxt_component_1;
      const _component_NuxtPage = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: `${unref(darkMode).value ? "dark" : ""} flex h-full`
      }, _attrs))} data-v-972ad866>`);
      _push(ssrRenderComponent(_component_dash_side_menu, null, null, _parent));
      _push(`<div id="content" class="${ssrRenderClass(`flex-col flex-grow ${unref(sideMenuOpen) ? "ml-[270px]" : ""}`)}" data-v-972ad866>`);
      _push(ssrRenderComponent(_component_dash_top_menu, null, null, _parent));
      _push(`<div class="bg-dash-light-300 dark:bg-dash-dark p-2 h-full" data-v-972ad866>`);
      _push(ssrRenderComponent(_component_NuxtPage, null, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/dash.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const dash = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-972ad866"]]);

export { dash as default };
//# sourceMappingURL=dash-d7ee2195.mjs.map
