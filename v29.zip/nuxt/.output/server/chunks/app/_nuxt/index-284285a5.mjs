import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { a as _sfc_main$3, _ as __nuxt_component_0$1 } from './card-page-layout-1deba93a.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-744fccd2.mjs';
import { _ as __nuxt_component_3 } from './lang-switcher-0c2f3c96.mjs';
import { useSSRContext, defineComponent, inject, ref, withAsyncContext, resolveComponent, unref, withCtx, createVNode, toDisplayString } from 'vue';
import { l as loadTranslations } from '../server.mjs';
import { ssrRenderComponent, ssrRenderAttr, ssrRenderClass, ssrInterpolate, ssrRenderStyle } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';
import './hamburger-menu-button-838d7b8a.mjs';
import 'i18next-vue';
import 'unctx';
import 'vue-router';
import 'parse/dist/parse.min.js';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'cookie-es';
import 'pinia-plugin-persistedstate';
import 'i18next';

const _imports_0 = "" + buildAssetsURL("shortIntro-compressed.e6839cd4.mp4");
const _imports_1 = "" + buildAssetsURL("shortIntroLastFrame.f94ad735.jpg");
const _imports_2 = "" + buildAssetsURL("castor-square.6080d437.jpg");
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const firstTime = inject("first_time_at_home");
    const showUI = ref(!firstTime.value);
    const showVideo = ref(true);
    [__temp, __restore] = withAsyncContext(() => loadTranslations("home")), __temp = await __temp, __restore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_base_navbar = _sfc_main$3;
      const _component_NuxtLink = __nuxt_component_0;
      const _component_base_card_page_layout = __nuxt_component_0$1;
      const _component_base_lang_switcher = __nuxt_component_3;
      const _component_i18next = resolveComponent("i18next");
      _push(`<!--[--><div class="bg-[rgb(6,7,10)] fixed h-full w-full z-[-20]" data-v-cb2c6aa1></div><div class="" data-v-cb2c6aa1><div class="flex justify-center relative" data-v-cb2c6aa1><div class="bg-[rgb(6,7,10)] w-full h-full absolute z-[-10]" data-v-cb2c6aa1></div><div class="overflow-hidden flex justify-center relative" data-v-cb2c6aa1>`);
      if (unref(showUI)) {
        _push(`<div class="absolute z-[10] top-0 w-full navbarAnimation" data-v-cb2c6aa1>`);
        _push(ssrRenderComponent(_component_base_navbar, { transparent: "true" }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="bg-video-gradient" data-v-cb2c6aa1></div><video id="video" fetchpriority="high"${ssrRenderAttr("src", _imports_0)} class="${ssrRenderClass(`${!unref(showVideo) ? "!hidden" : ""} video-size`)}" muted playsInline data-v-cb2c6aa1></video><img${ssrRenderAttr("src", _imports_1)} class="${ssrRenderClass(`${unref(showVideo) ? "hidden" : ""} video-size`)}" data-v-cb2c6aa1></div></div>`);
      if (unref(showUI)) {
        _push(`<div class="flex justify-center overflow-hidden" data-v-cb2c6aa1><div class="bg-video-overlay" data-v-cb2c6aa1>`);
        _push(ssrRenderComponent(_component_NuxtLink, { to: "/auth/sign-up" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<button class="bg-[#EE6065] rounded-full px-5 hxs:py-4 hsm:py-5 text-[#FFFFFFEE] font-family font-bold tracking-wider text-[23.5px] leading-[23.5px] videoButtonAnimation hxs:-mb-1 hsm:mb-2" data-v-cb2c6aa1${_scopeId}>${ssrInterpolate(_ctx.$t("home:button"))}</button>`);
            } else {
              return [
                createVNode("button", { class: "bg-[#EE6065] rounded-full px-5 hxs:py-4 hsm:py-5 text-[#FFFFFFEE] font-family font-bold tracking-wider text-[23.5px] leading-[23.5px] videoButtonAnimation hxs:-mb-1 hsm:mb-2" }, toDisplayString(_ctx.$t("home:button")), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="cardDiv hidden" data-v-cb2c6aa1>`);
      _push(ssrRenderComponent(_component_base_card_page_layout, {
        hideNavbar: "true",
        class: "pt-5 hsm:-translate-y-[100px] hxs:-translate-y-[70px] opacity-0 cardShow",
        backdropClass: "background",
        imgSrc: "../assets/bridgestars/art/home_page.svg"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_base_lang_switcher, { class: "mb-4" }, null, _parent2, _scopeId));
            _push2(`<div class="xs:px-0 sm:px-5 text-center flex flex-col items-center" data-v-cb2c6aa1${_scopeId}><h1 class="mb-6 balance-text xs:text-[23px] xs:leading-[29px] sm:text-[40px] sm:leading-[44px] max-w-[700px]" data-v-cb2c6aa1${_scopeId}>${ssrInterpolate(_ctx.$t("home:revolutionize.title"))}</h1><span class="text2 px-3 text-[20px] leading-[24px] max-w-[700px]" data-v-cb2c6aa1${_scopeId}>${ssrInterpolate(_ctx.$t("home:revolutionize.desc1"))}</span></div><div class="flex flex-wrap p-1 quote-bg w-full mt-[75px]" data-v-cb2c6aa1${_scopeId}><div class="sm:py-3 px-3 sm:w-[30%] flex justify-center items-center" data-v-cb2c6aa1${_scopeId}><img class="bg-dark xs:w-[55%] sm:w-[100%] object-scale-down rounded-[25px] xs:translate-y-[-50px] sm:translate-y-0"${ssrRenderAttr("src", _imports_2)} data-v-cb2c6aa1${_scopeId}></div><div class="opacity-[90%] xs:w-full sm:w-[70%] flex flex-col justify-center self-center pl-3 pr-7 lg:pr-[100px] lg:pl-[50px] sm:py-4 xs:-translate-y-5 sm:translate-y-0" data-v-cb2c6aa1${_scopeId}><div class="flex" data-v-cb2c6aa1${_scopeId}><div class="flex flex-col items-center px-1 pt-[6px] space-y-[5px]" data-v-cb2c6aa1${_scopeId}><div class="bg-white h-[40%] w-[3px]" data-v-cb2c6aa1${_scopeId}></div><span class="i-material-symbols-format-quote-rounded" style="${ssrRenderStyle({ "color": "white", "height": "20px", "width": "20px" })}" data-v-cb2c6aa1${_scopeId}></span><div class="bg-white h-[40%] w-[3px]" data-v-cb2c6aa1${_scopeId}></div></div><span class="text1 italic text-white text-[18px] leading-[25px]" data-v-cb2c6aa1${_scopeId}>${ssrInterpolate(_ctx.$t("home:quote.desc1"))}</span></div><div class="w-full flex flex-col pl-[29px]" data-v-cb2c6aa1${_scopeId}><div class="mt-5" data-v-cb2c6aa1${_scopeId}><span class="text-white font-family2 font-bold text-[18px]" data-v-cb2c6aa1${_scopeId}>Castor Mann, </span><span class="text-white font-light font-family2 ml-2" data-v-cb2c6aa1${_scopeId}>${ssrInterpolate(_ctx.$t("home:quote.castor"))}</span></div></div></div></div><div class="xs:px-0 sm:px-5 text-center flex flex-col items-center py-[55px] overflow-hidden" data-v-cb2c6aa1${_scopeId}><span class="rounded-full text-[12px] uppercase py-[4px] px-[10px] text-[#d23759] bg-[#f8b3ca] font-bold mb-[2px]" data-v-cb2c6aa1${_scopeId}>${ssrInterpolate(_ctx.$t("home:contact.title1"))}</span><h1 class="mb-[6px] balance-text xs:text-[20px] xs:leading-[30px] sm:text-[30px] sm:leading-[40px] max-w-[700px] bg-green" data-v-cb2c6aa1${_scopeId}>${ssrInterpolate(_ctx.$t("home:contact.title2"))}</h1><span class="text2 px-3 text-[18px] leading-[22px] max-w-[700px] mb-[20px]" data-v-cb2c6aa1${_scopeId}>`);
            _push2(ssrRenderComponent(_component_i18next, {
              translation: _ctx.$t("home:contact.desc1")
            }, {
              email: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<a class="text-blue font-normal underline"${ssrRenderAttr("href", `mailto:info@bridgestars.net?subject=${_ctx.$t("home:contact.emailSubject")}&body=${_ctx.$t("home:contact.emailBody")}`)} target="_blank" rel="noreferrer" data-v-cb2c6aa1${_scopeId2}> info@bridgestars.net</a>`);
                } else {
                  return [
                    createVNode("a", {
                      class: "text-blue font-normal underline",
                      href: `mailto:info@bridgestars.net?subject=${_ctx.$t("home:contact.emailSubject")}&body=${_ctx.$t("home:contact.emailBody")}`,
                      target: "_blank",
                      rel: "noreferrer"
                    }, " info@bridgestars.net", 8, ["href"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</span></div>`);
          } else {
            return [
              createVNode(_component_base_lang_switcher, { class: "mb-4" }),
              createVNode("div", { class: "xs:px-0 sm:px-5 text-center flex flex-col items-center" }, [
                createVNode("h1", { class: "mb-6 balance-text xs:text-[23px] xs:leading-[29px] sm:text-[40px] sm:leading-[44px] max-w-[700px]" }, toDisplayString(_ctx.$t("home:revolutionize.title")), 1),
                createVNode("span", { class: "text2 px-3 text-[20px] leading-[24px] max-w-[700px]" }, toDisplayString(_ctx.$t("home:revolutionize.desc1")), 1)
              ]),
              createVNode("div", { class: "flex flex-wrap p-1 quote-bg w-full mt-[75px]" }, [
                createVNode("div", { class: "sm:py-3 px-3 sm:w-[30%] flex justify-center items-center" }, [
                  createVNode("img", {
                    class: "bg-dark xs:w-[55%] sm:w-[100%] object-scale-down rounded-[25px] xs:translate-y-[-50px] sm:translate-y-0",
                    src: _imports_2
                  })
                ]),
                createVNode("div", { class: "opacity-[90%] xs:w-full sm:w-[70%] flex flex-col justify-center self-center pl-3 pr-7 lg:pr-[100px] lg:pl-[50px] sm:py-4 xs:-translate-y-5 sm:translate-y-0" }, [
                  createVNode("div", { class: "flex" }, [
                    createVNode("div", { class: "flex flex-col items-center px-1 pt-[6px] space-y-[5px]" }, [
                      createVNode("div", { class: "bg-white h-[40%] w-[3px]" }),
                      createVNode("span", {
                        class: "i-material-symbols-format-quote-rounded",
                        style: { "color": "white", "height": "20px", "width": "20px" }
                      }),
                      createVNode("div", { class: "bg-white h-[40%] w-[3px]" })
                    ]),
                    createVNode("span", { class: "text1 italic text-white text-[18px] leading-[25px]" }, toDisplayString(_ctx.$t("home:quote.desc1")), 1)
                  ]),
                  createVNode("div", { class: "w-full flex flex-col pl-[29px]" }, [
                    createVNode("div", { class: "mt-5" }, [
                      createVNode("span", { class: "text-white font-family2 font-bold text-[18px]" }, "Castor Mann, "),
                      createVNode("span", { class: "text-white font-light font-family2 ml-2" }, toDisplayString(_ctx.$t("home:quote.castor")), 1)
                    ])
                  ])
                ])
              ]),
              createVNode("div", { class: "xs:px-0 sm:px-5 text-center flex flex-col items-center py-[55px] overflow-hidden" }, [
                createVNode("span", { class: "rounded-full text-[12px] uppercase py-[4px] px-[10px] text-[#d23759] bg-[#f8b3ca] font-bold mb-[2px]" }, toDisplayString(_ctx.$t("home:contact.title1")), 1),
                createVNode("h1", { class: "mb-[6px] balance-text xs:text-[20px] xs:leading-[30px] sm:text-[30px] sm:leading-[40px] max-w-[700px] bg-green" }, toDisplayString(_ctx.$t("home:contact.title2")), 1),
                createVNode("span", { class: "text2 px-3 text-[18px] leading-[22px] max-w-[700px] mb-[20px]" }, [
                  createVNode(_component_i18next, {
                    translation: _ctx.$t("home:contact.desc1")
                  }, {
                    email: withCtx(() => [
                      createVNode("a", {
                        class: "text-blue font-normal underline",
                        href: `mailto:info@bridgestars.net?subject=${_ctx.$t("home:contact.emailSubject")}&body=${_ctx.$t("home:contact.emailBody")}`,
                        target: "_blank",
                        rel: "noreferrer"
                      }, " info@bridgestars.net", 8, ["href"])
                    ]),
                    _: 1
                  }, 8, ["translation"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-cb2c6aa1"]]);

export { index as default };
//# sourceMappingURL=index-284285a5.mjs.map
