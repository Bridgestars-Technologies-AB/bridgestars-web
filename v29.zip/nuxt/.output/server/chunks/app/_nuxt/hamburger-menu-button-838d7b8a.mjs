import { useSSRContext, defineComponent, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderClass } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "hamburger-menu-button",
  __ssrInlineRender: true,
  props: ["isOpen", "class", "innerClass"],
  emits: ["click"],
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        id: "nav-icon3",
        class: props.class + " " + (__props.isOpen ? "open" : "")
      }, _attrs))} data-v-d8704e30><!--[-->`);
      ssrRenderList(4, (i) => {
        _push(`<span class="${ssrRenderClass(props.innerClass || "bg-dark")}" data-v-d8704e30></span>`);
      });
      _push(`<!--]--></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/base/hamburger-menu-button.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-d8704e30"]]);

export { __nuxt_component_1 as _ };
//# sourceMappingURL=hamburger-menu-button-838d7b8a.mjs.map
