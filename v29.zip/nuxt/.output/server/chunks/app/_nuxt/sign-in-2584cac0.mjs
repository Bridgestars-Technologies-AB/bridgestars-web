import { _ as __nuxt_component_0$1, a as __nuxt_component_1, b as __nuxt_component_2 } from './submit-button-becc570b.mjs';
import { useSSRContext, defineComponent, ref, withAsyncContext, watch, mergeProps, withCtx, unref, createVNode, toDisplayString } from 'vue';
import { a as useRouter, d as useRoute, b as useToast, l as loadTranslations, e as useAuth, n as navigateTo } from '../server.mjs';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';
import 'unctx';
import 'vue-router';
import 'parse/dist/parse.min.js';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'cookie-es';
import 'pinia-plugin-persistedstate';
import 'i18next';
import 'i18next-vue';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "sign-in",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRouter();
    useRoute();
    const toast = useToast();
    const query = ref({});
    [__temp, __restore] = withAsyncContext(() => loadTranslations("auth")), __temp = await __temp, __restore();
    const auth = useAuth();
    watch(query, () => {
    });
    function submit(res) {
      auth.signIn(res.usernameEmail, res.password).then((user) => {
        toast.success("You are signed in!");
        if (query.value.to)
          navigateTo({ path: query.value.to });
        else
          navigateTo({ path: "/dash" });
      }).catch((e) => toast.error(e.message));
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_auth_form = __nuxt_component_0$1;
      const _component_base_input_field = __nuxt_component_1;
      const _component_base_submit_button = __nuxt_component_2;
      _push(ssrRenderComponent(_component_auth_form, mergeProps({
        header: _ctx.$t("auth:common.signIn"),
        title: _ctx.$t("auth:signIn.title"),
        subtitle: _ctx.$t("auth:signIn.subtitle"),
        onSubmit: submit
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_base_input_field, {
              wrapperClass: "w-[100%]",
              placeholder: _ctx.$t("auth:placeholder.usernameEmail"),
              modelValue: unref(query).email,
              "onUpdate:modelValue": ($event) => unref(query).email = $event,
              id: "username-email"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_base_input_field, {
              wrapperClass: "w-[100%]",
              placeholder: _ctx.$t("auth:placeholder.password"),
              type: "password",
              id: "password-signin"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_base_submit_button, {
              wrapperClass: "w-[100%] !mt-6",
              id: "submit",
              text: _ctx.$t("auth:common.signIn")
            }, null, _parent2, _scopeId));
            _push2(`<div class="!mt-6 whitespace-nowrap"${_scopeId}><span class="text2 mr-1"${_scopeId}>${ssrInterpolate(_ctx.$t("auth:signIn.footer"))}</span><button type="button" class="text-blue font-bold normal-case tracking-[0.5px]"${_scopeId}>${ssrInterpolate(_ctx.$t("auth:common.signUp"))}</button></div><div${_scopeId}><button class="text-blue font-bold normal-case tracking-[0.5px] translate-y-[-12px]" type="button"${_scopeId}>${ssrInterpolate(_ctx.$t("auth:signIn.forgot"))}</button></div>`);
          } else {
            return [
              createVNode(_component_base_input_field, {
                wrapperClass: "w-[100%]",
                placeholder: _ctx.$t("auth:placeholder.usernameEmail"),
                modelValue: unref(query).email,
                "onUpdate:modelValue": ($event) => unref(query).email = $event,
                id: "username-email"
              }, null, 8, ["placeholder", "modelValue", "onUpdate:modelValue"]),
              createVNode(_component_base_input_field, {
                wrapperClass: "w-[100%]",
                placeholder: _ctx.$t("auth:placeholder.password"),
                type: "password",
                id: "password-signin"
              }, null, 8, ["placeholder"]),
              createVNode(_component_base_submit_button, {
                wrapperClass: "w-[100%] !mt-6",
                id: "submit",
                text: _ctx.$t("auth:common.signIn")
              }, null, 8, ["text"]),
              createVNode("div", { class: "!mt-6 whitespace-nowrap" }, [
                createVNode("span", { class: "text2 mr-1" }, toDisplayString(_ctx.$t("auth:signIn.footer")), 1),
                createVNode("button", {
                  type: "button",
                  onClick: ($event) => ("navigateTo" in _ctx ? _ctx.navigateTo : unref(navigateTo))({ path: "/auth/sign-up", query: unref(query) }),
                  class: "text-blue font-bold normal-case tracking-[0.5px]"
                }, toDisplayString(_ctx.$t("auth:common.signUp")), 9, ["onClick"])
              ]),
              createVNode("div", null, [
                createVNode("button", {
                  onClick: ($event) => ("navigateTo" in _ctx ? _ctx.navigateTo : unref(navigateTo))({ path: "/auth/reset", query: unref(query) }),
                  class: "text-blue font-bold normal-case tracking-[0.5px] translate-y-[-12px]",
                  type: "button"
                }, toDisplayString(_ctx.$t("auth:signIn.forgot")), 9, ["onClick"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/auth/sign-in.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_auth_sign_in = _sfc_main$1;
  _push(ssrRenderComponent(_component_auth_sign_in, _attrs, null, _parent));
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/auth/sign-in.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const signIn = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { signIn as default };
//# sourceMappingURL=sign-in-2584cac0.mjs.map
