import { _ as __nuxt_component_0$1, a as __nuxt_component_1, b as __nuxt_component_2 } from './submit-button-becc570b.mjs';
import { useSSRContext, defineComponent, ref, withAsyncContext, mergeProps, withCtx, unref, createVNode, toDisplayString } from 'vue';
import { a as useRouter, b as useToast, d as useRoute, l as loadTranslations } from '../server.mjs';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';
import 'unctx';
import 'vue-router';
import 'parse/dist/parse.min.js';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'cookie-es';
import 'pinia-plugin-persistedstate';
import 'i18next';
import 'i18next-vue';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Reset",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const router = useRouter();
    const toast = useToast();
    useRoute();
    const query = ref({});
    const { t } = ([__temp, __restore] = withAsyncContext(() => loadTranslations("auth")), __temp = await __temp, __restore(), __temp);
    function submit(res) {
      toast.success(t("auth:reset:toast.passwordReset"));
      query.value.email = res.email;
      router.push({ path: "/auth/sign-in", query: query.value });
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_auth_form = __nuxt_component_0$1;
      const _component_base_input_field = __nuxt_component_1;
      const _component_base_submit_button = __nuxt_component_2;
      _push(ssrRenderComponent(_component_auth_form, mergeProps({
        header: _ctx.$t("auth:reset.resetPassword"),
        title: _ctx.$t("auth:reset.title"),
        subtitle: _ctx.$t("auth:reset.subtitle"),
        onSubmit: submit
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_base_input_field, {
              wrapperClass: "w-[100%]",
              placeholder: _ctx.$t("auth:placeholder.email"),
              modelValue: unref(query).email,
              "onUpdate:modelValue": ($event) => unref(query).email = $event,
              id: "email"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_base_submit_button, {
              wrapperClass: "w-[100%] !mt-6",
              id: "submit",
              text: _ctx.$t("auth:reset.resetPassword")
            }, null, _parent2, _scopeId));
            _push2(`<div class="!mt-6 whitespace-nowrap"${_scopeId}><span class="text2 mr-1"${_scopeId}>${ssrInterpolate(_ctx.$t("auth:reset.footer"))}</span><button type="button" class="!text-[16px] normal-case text-blue font-bold normal-case tracking-[0.5px]"${_scopeId}>${ssrInterpolate(_ctx.$t("auth:reset.goBack"))}</button></div>`);
          } else {
            return [
              createVNode(_component_base_input_field, {
                wrapperClass: "w-[100%]",
                placeholder: _ctx.$t("auth:placeholder.email"),
                modelValue: unref(query).email,
                "onUpdate:modelValue": ($event) => unref(query).email = $event,
                id: "email"
              }, null, 8, ["placeholder", "modelValue", "onUpdate:modelValue"]),
              createVNode(_component_base_submit_button, {
                wrapperClass: "w-[100%] !mt-6",
                id: "submit",
                text: _ctx.$t("auth:reset.resetPassword")
              }, null, 8, ["text"]),
              createVNode("div", { class: "!mt-6 whitespace-nowrap" }, [
                createVNode("span", { class: "text2 mr-1" }, toDisplayString(_ctx.$t("auth:reset.footer")), 1),
                createVNode("button", {
                  onClick: ($event) => unref(router).go(-1),
                  type: "button",
                  class: "!text-[16px] normal-case text-blue font-bold normal-case tracking-[0.5px]"
                }, toDisplayString(_ctx.$t("auth:reset.goBack")), 9, ["onClick"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/auth/Reset.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_auth_reset = _sfc_main$1;
  _push(ssrRenderComponent(_component_auth_reset, _attrs, null, _parent));
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/auth/reset.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const reset = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { reset as default };
//# sourceMappingURL=reset-a686476d.mjs.map
