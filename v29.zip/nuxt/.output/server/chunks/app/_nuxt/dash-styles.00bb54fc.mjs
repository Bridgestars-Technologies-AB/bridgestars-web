const sideMenu_vue_vue_type_style_index_0_scoped_354a07a2_lang = "#side-menu[data-v-354a07a2]{transition:left .3s ease-in-out,background-color .2s ease-in-out,color .2s ease-in-out}";

const dash_vue_vue_type_style_index_0_scoped_972ad866_lang = "#content[data-v-972ad866]{transition:margin-left .3s ease-in-out}body[data-v-972ad866],html[data-v-972ad866]{overflow-x:hidden;overflow-y:hidden}#__nuxt[data-v-972ad866],body[data-v-972ad866],html[data-v-972ad866]{height:100%}*[data-v-972ad866]{transition:background-color .2s ease-in-out,color .2s ease-in-out}";

const dashStyles_00bb54fc = [sideMenu_vue_vue_type_style_index_0_scoped_354a07a2_lang, dash_vue_vue_type_style_index_0_scoped_972ad866_lang, dash_vue_vue_type_style_index_0_scoped_972ad866_lang];

export { dashStyles_00bb54fc as default };
//# sourceMappingURL=dash-styles.00bb54fc.mjs.map
