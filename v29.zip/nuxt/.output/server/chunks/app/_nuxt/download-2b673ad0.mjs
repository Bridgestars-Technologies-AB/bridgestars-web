const desc1 = "Bridgestars is now available for choosen members on Windows and Mac OS. To get started, download the software below and let us guide you through the process of becoming one of our trusted users. If anytime, you forget your password, then just apply for a new one {here}.";
const desc2 = "We appreciate all your feedback. Please reach out to us via {discord} or {email} if you encounter any problems with the app. You are also welcome to submit requests for new features.";
const desc3 = "The app will require at most 1 GB of disk space. Make sure to have some space left on your computer.";
const desc4 = "The Windows installer may trigger Windows Smart Screen which may warn you about the application, there is nothing that can be done about this.";
const title = "Welcome to Bridgestars!";
const download = "Download";
const size = "Download size: {{size}}";
const mac = {
  title: "Bridgestars for Mac OS (.app)",
  description: "This version is for Mac OS (Apple). Once downloaded and started, it will ask wether you want a shortcut on your desktop."
};
const win = {
  title: "Bridgestars for Windows (.exe)",
  description: "This version is for Windows (PC). Once downloaded, start the application directly from your downloads. This will automatically create a shortcut on your desktop."
};
const isMobile = "We are working on making Bridgestars available on your mobile device. In the meantime, please return to this page on your computer!";
const isOtherOS = "We are working on making Bridgestars available on your device. In the meantime, please return to this page on your Windows or Mac computer!";
const showOptions = "Show all download options";
const download$1 = {
  desc1,
  desc2,
  desc3,
  desc4,
  title,
  download,
  size,
  mac,
  win,
  isMobile,
  isOtherOS,
  showOptions
};

export { download$1 as default, desc1, desc2, desc3, desc4, download, isMobile, isOtherOS, mac, showOptions, size, title, win };
//# sourceMappingURL=download-2b673ad0.mjs.map
