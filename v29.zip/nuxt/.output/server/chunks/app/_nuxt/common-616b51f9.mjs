const here = "H\xE4r";
const home = "Hem";
const profile = "Profil";
const policy = "Villkor";
const downloads = "Nedladdningar";
const misc = {
  copyright: "Copyright \xA9 {{year}} Bridgestars by Bridgestars Technologies Sweden AB."
};
const common = {
  here,
  home,
  profile,
  policy,
  downloads,
  misc
};

export { common as default, downloads, here, home, misc, policy, profile };
//# sourceMappingURL=common-616b51f9.mjs.map
