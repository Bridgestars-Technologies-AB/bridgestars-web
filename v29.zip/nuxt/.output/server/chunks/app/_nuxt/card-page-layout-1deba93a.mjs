import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-744fccd2.mjs';
import { _ as __nuxt_component_1$2 } from './hamburger-menu-button-838d7b8a.mjs';
import { useTranslation } from 'i18next-vue';
import { e as useAuth } from '../server.mjs';
import { useSSRContext, defineComponent, reactive, ref, mergeProps, unref, withCtx, createVNode, toDisplayString, createTextVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderClass, ssrRenderComponent, ssrRenderAttr, ssrRenderStyle, ssrRenderList, ssrInterpolate, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';

function useTranslate() {
  const { t, i18next } = useTranslation();
  return { t, i18: i18next };
}
const _imports_0$1 = "" + buildAssetsURL("logo-trans-128px.c1860341.png");
const success = "#59BA83";
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "Navbar",
  __ssrInlineRender: true,
  props: ["transparent"],
  setup(__props) {
    const props = __props;
    const { t, i18 } = useTranslate();
    const auth = useAuth();
    const routes = reactive([
      {
        key: "home",
        path: "/",
        icon: "i-material-symbols-home-rounded"
      },
      {
        key: "profile",
        path: "/auth/sign-in",
        icon: "i-ic-baseline-account-circle"
      }
    ]);
    function updateRoutes() {
      routes.forEach((route) => {
        if (!route.success)
          route.name = t("common:" + route.key);
      });
    }
    i18.on("languageChanged", (lng) => {
      updateRoutes();
    });
    updateRoutes();
    const isOpen = ref(false);
    const bgColor = props.transparent ? "bg-[#FFFFFF00]" : "bg-white";
    const textColor = props.transparent ? "!text-white" : "!text-dark";
    const menuIconColor = props.transparent ? "bg-white" : "bg-dark";
    const iconColor = props.transparent ? "#FFFFFF" : "rgb(120,120,120)";
    if (auth.authenticated) {
      const account = routes.find((route) => route.key === "profile");
      account.name = auth.get("dispName");
      account.path = "/dash";
      account.success = true;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_base_hamburger_menu_button = __nuxt_component_1$2;
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<header${ssrRenderAttrs(mergeProps({ class: "w-full" }, _attrs))}><nav class="${ssrRenderClass("flex xs:flex-wrap sm:flex-nowrap justify-between items-center w-[100%] py-4 px-2 mb-2 rounded-2xl " + unref(bgColor))}"><div class="flex items-center sm:w-auto">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0$1)} class="h-[32px] w-[32px] mx-2"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0$1,
                class: "h-[32px] w-[32px] mx-2"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h3 class="${ssrRenderClass("text-[22px] " + unref(textColor))}"${_scopeId}>Bridgestars</h3>`);
          } else {
            return [
              createVNode("h3", {
                class: "text-[22px] " + unref(textColor)
              }, "Bridgestars", 2)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex items-center sm:hidden mr-2">`);
      _push(ssrRenderComponent(_component_base_hamburger_menu_button, {
        onClick: ($event) => isOpen.value = !unref(isOpen),
        isOpen: unref(isOpen),
        class: "!scale-[0.3]",
        innerClass: unref(menuIconColor)
      }, null, _parent));
      if (unref(auth).authenticated) {
        _push(`<span class="i-ic-baseline-account-circle !scale-[1.35]" style="${ssrRenderStyle("color: " + success)}"></span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="${ssrRenderClass(`w-full sm:w-auto sm:block ${!unref(isOpen) ? "xs:hidden" : ""}`)}"><ul class="sm:flex sm:justify-end sm:p-0 xs:p-1"><!--[-->`);
      ssrRenderList(unref(routes), (route) => {
        _push(`<li class="block mx-2">`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: route.path,
          class: "text-[14px]"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex items-center space-x-2 mx-1 xs:mt-3 sm:mt-0"${_scopeId}><div class="${ssrRenderClass(`scale-[1.3] ${route.icon}`)}" style="${ssrRenderStyle(`color:${route.success ? success : unref(iconColor)};`)}"${_scopeId}></div><span class="${ssrRenderClass(`text2 !text-[18px] !font-medium
                    ${route.success ? "!text-[#59BA83]" : unref(textColor)}`)}"${_scopeId}>${ssrInterpolate(route.name)}</span></div>`);
            } else {
              return [
                createVNode("div", { class: "flex items-center space-x-2 mx-1 xs:mt-3 sm:mt-0" }, [
                  createVNode("div", {
                    class: `scale-[1.3] ${route.icon}`,
                    style: `color:${route.success ? success : unref(iconColor)};`
                  }, null, 6),
                  createVNode("span", {
                    class: `text2 !text-[18px] !font-medium
                    ${route.success ? "!text-[#59BA83]" : unref(textColor)}`
                  }, toDisplayString(route.name), 3)
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</li>`);
      });
      _push(`<!--]--></ul></div></nav></header>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/base/Navbar.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "tooltip",
  __ssrInlineRender: true,
  props: {
    text: {},
    position: {}
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: _ctx.position,
        "data-tooltip": _ctx.text,
        "data-position": _ctx.position
      }, _attrs))} data-v-a48b2c16>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/base/tooltip.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1$1 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-a48b2c16"]]);
const _imports_0 = "" + buildAssetsURL("facebook-dark.51a57591.svg");
const _imports_1 = "" + buildAssetsURL("instagram-dark.e71ede31.svg");
const _imports_2 = "" + buildAssetsURL("discord-dark.8c651974.svg");
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLink = __nuxt_component_0$1;
  const _component_base_tooltip = __nuxt_component_1$1;
  _push(`<footer${ssrRenderAttrs(mergeProps({ class: "mt-[100px] space-y-5 px-3" }, _attrs))}><div class="flex space-x-5 justify-center flex-wrap">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    class: "",
    href: "/"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`${ssrInterpolate(_ctx.$t("common:home"))}`);
      } else {
        return [
          createTextVNode(toDisplayString(_ctx.$t("common:home")), 1)
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    class: "",
    href: "/auth/sign-in"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`${ssrInterpolate(_ctx.$t("common:profile"))}`);
      } else {
        return [
          createTextVNode(toDisplayString(_ctx.$t("common:profile")), 1)
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    class: "",
    href: "/download"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`${ssrInterpolate(_ctx.$t("common:downloads"))}`);
      } else {
        return [
          createTextVNode(toDisplayString(_ctx.$t("common:downloads")), 1)
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    class: "",
    href: "/policy"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`${ssrInterpolate(_ctx.$t("common:policy"))}`);
      } else {
        return [
          createTextVNode(toDisplayString(_ctx.$t("common:policy")), 1)
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="flex space-x-5 justify-center">`);
  _push(ssrRenderComponent(_component_base_tooltip, {
    text: "Facebook",
    position: "bottom"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<a class="bottom" href="https://www.facebook.com/BridgestarsTechnologies" target="_blank" rel="noreferrer"${_scopeId}><img class="h-[20px] hover:animate-shake"${ssrRenderAttr("src", _imports_0)}${_scopeId}></a>`);
      } else {
        return [
          createVNode("a", {
            class: "bottom",
            href: "https://www.facebook.com/BridgestarsTechnologies",
            target: "_blank",
            rel: "noreferrer"
          }, [
            createVNode("img", {
              class: "h-[20px] hover:animate-shake",
              src: _imports_0
            })
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_base_tooltip, {
    text: "Instagram",
    position: "bottom"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<a class="bottom" href="https://www.instagram.com/bridgestars/" target="_blank" rel="noreferrer"${_scopeId}><img class="h-[20px] hover:animate-shake"${ssrRenderAttr("src", _imports_1)}${_scopeId}></a>`);
      } else {
        return [
          createVNode("a", {
            class: "bottom",
            href: "https://www.instagram.com/bridgestars/",
            target: "_blank",
            rel: "noreferrer"
          }, [
            createVNode("img", {
              class: "h-[20px] hover:animate-shake",
              src: _imports_1
            })
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_base_tooltip, {
    text: "Discord",
    position: "bottom"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<a class="bottom" href="https://discord.gg/YhwRDgtSX2" target="_blank" rel="noreferrer"${_scopeId}><img class="h-[20px] hover:animate-shake"${ssrRenderAttr("src", _imports_2)}${_scopeId}></a>`);
      } else {
        return [
          createVNode("a", {
            class: "bottom",
            href: "https://discord.gg/YhwRDgtSX2",
            target: "_blank",
            rel: "noreferrer"
          }, [
            createVNode("img", {
              class: "h-[20px] hover:animate-shake",
              src: _imports_2
            })
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_base_tooltip, {
    text: "Email",
    position: "bottom"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<a href="mailto: info@bridgestars.net" target="_blank" rel="noreferrer"${_scopeId}><span class="i-material-symbols-mail-rounded h-[20px] w-[20px] hover:animate-shake" style="${ssrRenderStyle({ "color": "#3a3a40" })}"${_scopeId}></span></a>`);
      } else {
        return [
          createVNode("a", {
            href: "mailto: info@bridgestars.net",
            target: "_blank",
            rel: "noreferrer"
          }, [
            createVNode("span", {
              class: "i-material-symbols-mail-rounded h-[20px] w-[20px] hover:animate-shake",
              style: { "color": "#3a3a40" }
            })
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="flex justify-center text-center"><span class="text2 !text-[14px]">${ssrInterpolate(_ctx.$t("misc.copyright", { year: ( new Date()).getFullYear() }))}</span></div></footer>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/base/Footer.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "card-page-layout",
  __ssrInlineRender: true,
  props: ["imgSrc", "hideNavbar", "class", "backdropClass"],
  setup(__props) {
    const props = __props;
    const imgWithDefault = props.imgSrc || "../assets/bridgestars/art/about_us.svg";
    return (_ctx, _push, _parent, _attrs) => {
      const _component_base_navbar = _sfc_main$3;
      const _component_base_footer = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "backdrop " + __props.backdropClass
      }, _attrs))} data-v-f5ed00bb><div class="${ssrRenderClass(`foreground ${props.class}`)}" data-v-f5ed00bb>`);
      if (!__props.hideNavbar) {
        _push(ssrRenderComponent(_component_base_navbar, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<img${ssrRenderAttr("src", unref(imgWithDefault))} class="mb-5 xs:w-[96%] sm:w-[80%] xl:w-[50%]" data-v-f5ed00bb><div class="w-full flex flex-col items-center" data-v-f5ed00bb>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_base_footer, null, null, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/base/card-page-layout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-f5ed00bb"]]);

export { __nuxt_component_0 as _, _sfc_main$3 as a, useTranslate as u };
//# sourceMappingURL=card-page-layout-1deba93a.mjs.map
