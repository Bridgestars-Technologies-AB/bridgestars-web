import { u as useTranslate } from './card-page-layout-1deba93a.mjs';
import { useSSRContext, mergeProps, unref } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderClass, ssrRenderStyle } from 'vue/server-renderer';

const _sfc_main = {
  __name: "lang-switcher",
  __ssrInlineRender: true,
  emits: ["switched"],
  setup(__props, { emit }) {
    const { t, i18 } = useTranslate();
    const flags = {
      sv: "i-circle-flags-se",
      en: "i-circle-flags-gb"
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex space-x-2" }, _attrs))}><!--[-->`);
      ssrRenderList(["sv", "en"], (l) => {
        _push(`<span class="${ssrRenderClass(`${flags[l]} ${l != unref(i18).language ? "opacity-50" : ""}`)}" style="${ssrRenderStyle({ "height": "34px", "width": "34px" })}"></span>`);
      });
      _push(`<!--]--></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/base/lang-switcher.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main;

export { __nuxt_component_3 as _ };
//# sourceMappingURL=lang-switcher-0c2f3c96.mjs.map
