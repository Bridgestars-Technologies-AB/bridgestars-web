const side_menu = {
  analysis: "Analys",
  exercise: "\xD6vningar",
  other: "\xD6vrigt",
  overview: "\xD6versikt",
  "deal-editor": "Givredigerare",
  "contract-calc": "Kontraktber\xE4knare",
  simulator: "Simulator",
  contracting: "Budgivning",
  gambit: "Utspel",
  "suit-treatments": "F\xE4rgbehandlingar",
  play: "Spela",
  help: "Hj\xE4lp",
  results: "T\xE4vlingsresultat",
  "sign-out": "Logga ut"
};
const dashboard = {
  side_menu
};

export { dashboard as default, side_menu };
//# sourceMappingURL=dashboard-b3d435d7.mjs.map
