import { _ as __nuxt_component_0 } from './card-page-layout-1deba93a.mjs';
import { _ as __nuxt_component_3 } from './lang-switcher-0c2f3c96.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-744fccd2.mjs';
import { ref, withAsyncContext, reactive, resolveComponent, withCtx, createTextVNode, toDisplayString, createVNode, unref, openBlock, createBlock, Fragment, renderList, createCommentVNode, useSSRContext } from 'vue';
import { l as loadTranslations } from '../server.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr } from 'vue/server-renderer';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';
import './hamburger-menu-button-838d7b8a.mjs';
import './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'i18next-vue';
import 'unctx';
import 'vue-router';
import 'parse/dist/parse.min.js';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'cookie-es';
import 'pinia-plugin-persistedstate';
import 'i18next';

const _sfc_main = {
  __name: "download",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const downloads = ref([]);
    const { t } = ([__temp, __restore] = withAsyncContext(() => loadTranslations("download")), __temp = await __temp, __restore(), __temp);
    function update() {
      downloads.value = [
        {
          platform: "mac",
          title: t("download:mac.title"),
          description: t("download:mac.description"),
          size: "60MB",
          link: "https://bridgestars-static-host.s3.eu-north-1.amazonaws.com/launcher/mac/bridgestars-macos-1.1.8.zip"
        },
        {
          platform: "win",
          title: t("download:win.title"),
          description: t("download:win.description"),
          size: "60MB",
          link: "https://bridgestars-static-host.s3.eu-north-1.amazonaws.com/launcher/win/bridgestars-win-1.1.8.zip"
        }
      ];
    }
    update();
    const platform = reactive({
      isMac: false,
      isWindows: false,
      isMobile: false
    });
    const showOptions = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_base_card_page_layout = __nuxt_component_0;
      const _component_base_lang_switcher = __nuxt_component_3;
      const _component_i18next = resolveComponent("i18next");
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(ssrRenderComponent(_component_base_card_page_layout, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="max-w-[1000px] flex flex-col text-justify px-[16px]"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_base_lang_switcher, {
              class: "mb-4",
              onSwitched: update
            }, null, _parent2, _scopeId));
            _push2(`<h3 class="text-start"${_scopeId}>${ssrInterpolate(_ctx.$t("download:title"))}</h3><span class="text2 mt-2"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_i18next, {
              translation: _ctx.$t("download:desc1")
            }, {
              here: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_NuxtLink, {
                    to: "/auth/reset",
                    class: "text-blue font-normal underline"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`${ssrInterpolate(_ctx.$t("common:here").toLowerCase())}`);
                      } else {
                        return [
                          createTextVNode(toDisplayString(_ctx.$t("common:here").toLowerCase()), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_NuxtLink, {
                      to: "/auth/reset",
                      class: "text-blue font-normal underline"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(_ctx.$t("common:here").toLowerCase()), 1)
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</span><span class="text2 mt-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_i18next, {
              translation: _ctx.$t("download:desc2")
            }, {
              discord: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<a class="text-blue font-normal underline" href="https://discord.gg/YhwRDgtSX2" target="_blank" rel="noreferrer"${_scopeId2}> discord</a>`);
                } else {
                  return [
                    createVNode("a", {
                      class: "text-blue font-normal underline",
                      href: "https://discord.gg/YhwRDgtSX2",
                      target: "_blank",
                      rel: "noreferrer"
                    }, " discord")
                  ];
                }
              }),
              email: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<a class="text-blue font-normal underline" href="mailto: info@bridgestars.net" target="_blank" rel="noreferrer"${_scopeId2}> email</a>`);
                } else {
                  return [
                    createVNode("a", {
                      class: "text-blue font-normal underline",
                      href: "mailto: info@bridgestars.net",
                      target: "_blank",
                      rel: "noreferrer"
                    }, " email")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</span><span class="text2 mt-4"${_scopeId}>${ssrInterpolate(_ctx.$t("download:desc3"))}</span><span class="text2 mt-4"${_scopeId}>${ssrInterpolate(_ctx.$t("download:desc4"))}</span></div><div class="max-w-[800px] flex flex-col text-justify xs:px-0 px-[16px] mb-[32px]"${_scopeId}>`);
            if (unref(platform).isMac || unref(platform).isWindows || unref(showOptions)) {
              _push2(`<!--[-->`);
              ssrRenderList(unref(downloads), (d, i) => {
                _push2(`<div${_scopeId}>`);
                if (unref(showOptions) || !unref(showOptions) && i == 0) {
                  _push2(`<div class="px-6 py-4 mt-10 rounded-2xl shadow-2xl bg-[#FFFFFF] text-start flex items-center"${_scopeId}><div class="flex flex-col pr-6"${_scopeId}><h3${_scopeId}>${ssrInterpolate(d.title)}</h3><span class="text2 mt-2"${_scopeId}>${ssrInterpolate(d.description)}</span></div><div class="flex flex-col text-center"${_scopeId}><a${ssrRenderAttr("href", d.link)} class="bg-[#EE6065] rounded-full px-4 py-4 text-[#FFFFFFEE] font-family font-bold tracking-wider text-[20px] leading-[20px] whitespace-nowrap"${_scopeId}>${ssrInterpolate(_ctx.$t("download:download"))}</a><span class="text2 !text-[14px] mt-1 whitespace-nowrap"${_scopeId}>${ssrInterpolate(_ctx.$t("download:size", { size: d.size }))}</span></div></div>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</div>`);
              });
              _push2(`<!--]-->`);
            } else if (unref(platform).isMobile) {
              _push2(`<div class="text-center py-8"${_scopeId}><h3${_scopeId}>${ssrInterpolate(_ctx.$t("download:isMobile"))}</h3></div>`);
            } else {
              _push2(`<div class="text-center py-8"${_scopeId}><h3${_scopeId}>${ssrInterpolate(_ctx.$t("download:isOtherOS"))}</h3></div>`);
            }
            if (!unref(showOptions)) {
              _push2(`<button type="button" class="mt-10 !text-[16px] text-blue font-bold normal-case tracking-[0.5px]"${_scopeId}>${ssrInterpolate(_ctx.$t("download:showOptions"))}</button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "max-w-[1000px] flex flex-col text-justify px-[16px]" }, [
                createVNode(_component_base_lang_switcher, {
                  class: "mb-4",
                  onSwitched: update
                }),
                createVNode("h3", { class: "text-start" }, toDisplayString(_ctx.$t("download:title")), 1),
                createVNode("span", { class: "text2 mt-2" }, [
                  createVNode(_component_i18next, {
                    translation: _ctx.$t("download:desc1")
                  }, {
                    here: withCtx(() => [
                      createVNode(_component_NuxtLink, {
                        to: "/auth/reset",
                        class: "text-blue font-normal underline"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(_ctx.$t("common:here").toLowerCase()), 1)
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["translation"])
                ]),
                createVNode("span", { class: "text2 mt-4" }, [
                  createVNode(_component_i18next, {
                    translation: _ctx.$t("download:desc2")
                  }, {
                    discord: withCtx(() => [
                      createVNode("a", {
                        class: "text-blue font-normal underline",
                        href: "https://discord.gg/YhwRDgtSX2",
                        target: "_blank",
                        rel: "noreferrer"
                      }, " discord")
                    ]),
                    email: withCtx(() => [
                      createVNode("a", {
                        class: "text-blue font-normal underline",
                        href: "mailto: info@bridgestars.net",
                        target: "_blank",
                        rel: "noreferrer"
                      }, " email")
                    ]),
                    _: 1
                  }, 8, ["translation"])
                ]),
                createVNode("span", { class: "text2 mt-4" }, toDisplayString(_ctx.$t("download:desc3")), 1),
                createVNode("span", { class: "text2 mt-4" }, toDisplayString(_ctx.$t("download:desc4")), 1)
              ]),
              createVNode("div", { class: "max-w-[800px] flex flex-col text-justify xs:px-0 px-[16px] mb-[32px]" }, [
                unref(platform).isMac || unref(platform).isWindows || unref(showOptions) ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(downloads), (d, i) => {
                  return openBlock(), createBlock("div", { key: i }, [
                    unref(showOptions) || !unref(showOptions) && i == 0 ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "px-6 py-4 mt-10 rounded-2xl shadow-2xl bg-[#FFFFFF] text-start flex items-center"
                    }, [
                      createVNode("div", { class: "flex flex-col pr-6" }, [
                        createVNode("h3", null, toDisplayString(d.title), 1),
                        createVNode("span", { class: "text2 mt-2" }, toDisplayString(d.description), 1)
                      ]),
                      createVNode("div", { class: "flex flex-col text-center" }, [
                        createVNode("a", {
                          href: d.link,
                          class: "bg-[#EE6065] rounded-full px-4 py-4 text-[#FFFFFFEE] font-family font-bold tracking-wider text-[20px] leading-[20px] whitespace-nowrap"
                        }, toDisplayString(_ctx.$t("download:download")), 9, ["href"]),
                        createVNode("span", { class: "text2 !text-[14px] mt-1 whitespace-nowrap" }, toDisplayString(_ctx.$t("download:size", { size: d.size })), 1)
                      ])
                    ])) : createCommentVNode("", true)
                  ]);
                }), 128)) : unref(platform).isMobile ? (openBlock(), createBlock("div", {
                  key: 1,
                  class: "text-center py-8"
                }, [
                  createVNode("h3", null, toDisplayString(_ctx.$t("download:isMobile")), 1)
                ])) : (openBlock(), createBlock("div", {
                  key: 2,
                  class: "text-center py-8"
                }, [
                  createVNode("h3", null, toDisplayString(_ctx.$t("download:isOtherOS")), 1)
                ])),
                !unref(showOptions) ? (openBlock(), createBlock("button", {
                  key: 3,
                  onClick: ($event) => showOptions.value = true,
                  type: "button",
                  class: "mt-10 !text-[16px] text-blue font-bold normal-case tracking-[0.5px]"
                }, toDisplayString(_ctx.$t("download:showOptions")), 9, ["onClick"])) : createCommentVNode("", true)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/download.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=download-fae08f5b.mjs.map
