const button = "B\xF6rja nu";
const revolutionize = {
  title: "Tillsammans moderniserar vi Bridge-utbildningen",
  desc1: "Bridgestars vill st\xE4rka befintliga Bridge-utbildningar genom att tillhandah\xE5lla moderna och anv\xE4ndarv\xE4nliga IT-l\xF6sningar till b\xE5de Windows och Mac samt din surfplatta."
};
const quote = {
  desc1: "I en v\xE4rld full av tekniska framsteg har bridgev\xE4rlden inte lyckats h\xE4nga med. Vi \xE4r tv\xE5 studenter som har sett att det saknas en modern l\xF6sning f\xF6r att spela bridge som \xE4r rolig, enkel och engagerande. Sedan 2020 har vi utvecklat onlineplattformen Bridgestars som tar fokus p\xE5 utbildning, d\xE4r elever fr\xE5n svenska bridgeskolor f\xE5r chansen att utvecklas som bridgespelare. Elever kan spela bridge och \xE4ven f\xF6lja pedagogiska \xF6vningar p\xE5 plattformen. V\xE5r vision \xE4r att erbjuda en engagerande l\xE4rplattform f\xF6r alla bridge-elever, f\xF6r nyb\xF6rjare s\xE5 v\xE4l som erfarna spelare.",
  castor: "Bridgestars Grundare och Juniorv\xE4rldsm\xE4stare 2018."
};
const contact = {
  title1: "Kontakta oss",
  title2: "Intresserad av ett samarbete?",
  desc1: "Vi letar st\xE4ndigt efter nya samarbetspartners som kan hj\xE4lpa oss att uppn\xE5 v\xE5r vision om en b\xE4ttre bridgeundervisning. \xC4r du en bridgel\xE4rare som \xE4r nyfiken p\xE5 hur du kan f\xF6rb\xE4ttra dina elevers l\xE4randeupplevelse? Kontakta oss p\xE5 {email}, vi ser fram emot att h\xF6ra fr\xE5n er.",
  emailSubject: "Intresseanm\xE4lan",
  emailBody: "Hej Bridgestars,%0D%0AJag \xE4r intresserad av ett samarbete och skulle vilja veta mer om hur vi kan hj\xE4lpa varandra.%0D%0A%0D%0AMitt namn \xE4r:%0D%0A%0D%0ABridgeklubb:%0D%0A%0D%0AJag \xE4r intresserad av Bridgestars kopplat till: utbildning/skr\xE4ddarsydda IT-l\xF6sningar/Onlinebridge/annat"
};
const home = {
  button,
  revolutionize,
  quote,
  contact
};

export { button, contact, home as default, quote, revolutionize };
//# sourceMappingURL=home-74e1d7c1.mjs.map
