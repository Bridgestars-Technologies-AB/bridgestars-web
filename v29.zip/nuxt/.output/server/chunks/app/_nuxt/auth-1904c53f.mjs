const common = {
  signIn: "Logga In",
  signUp: "Registrera dig",
  home: "Hem"
};
const placeholder = {
  usernameEmail: "Anv\xE4ndarnamn/Email",
  password: "L\xF6senord",
  username: "Anv\xE4ndarnamn",
  email: "Email",
  confirmPassword: "Bekr\xE4fta l\xF6senord"
};
const signIn = {
  title: "Logga in till ditt Bridgestarskonto",
  subtitle: "Ange ditt anv\xE4ndarnamn och l\xF6senord",
  footer: "Har du inget konto?",
  forgot: "Gl\xF6mt ditt l\xF6senord?",
  toast: {
    alreadyIn: "dev: Du \xE4r redan inloggad, logga ut p\xE5 profilsidan",
    signedIn: "Du \xE4r inloggad!"
  }
};
const signUp = {
  title: "G\xE5 med i Bridgestars v\xE4ntelista",
  subtitle: "Fyll i dina anv\xE4ndaruppgifter nedan f\xF6r att skapa ett konto.",
  footer: "Har du redan ett konto?",
  toast: {
    signedUp: "Ditt konto \xE4r nu registrerat!"
  }
};
const reset = {
  title: "\xC5terst\xE4ll ditt Bridgestars l\xF6senord",
  subtitle: "Ange din e-postadress f\xF6r att \xE5terst\xE4lla ditt l\xF6senord.",
  resetPassword: "\xC5terst\xE4ll L\xF6senord",
  footer: "\xC5ngrat dig?",
  goBack: "G\xE5 Tillbaka",
  toast: {
    passwordReset: "Ditt l\xF6senord har \xE5test\xE4llts. En l\xE4nk har skickats till din mail."
  }
};
const error = {
  username: {
    length: "Ditt anv\xE4ndarnamn m\xE5ste vara mellan {{min}} och {{max}} tecken.",
    blank: "V\xE4nligen ange ditt Anv\xE4ndarnamn."
  },
  email: {
    blank: "V\xE4nligen ange din Email.",
    blankUserEmail: "V\xE4nligen ange ditt Anv\xE4ndarnamn/Email.",
    notValid: "Mailen du angav \xE4r inte giltig."
  },
  password: {
    blank: "V\xE4nligen ange ditt L\xF6senord.",
    atLeastChar: "Ditt L\xF6senord m\xE5ste inneh\xE5lla minst 8 tecken.",
    atLeastLower: "Ditt L\xF6senord m\xE5ste inneh\xE5lla minst en liten bokstav.",
    atLeastUpper: "Ditt L\xF6senord m\xE5ste inneh\xE5lla minst en stor bokstav.",
    atLeastDigit: "Ditt L\xF6senord m\xE5ste inneh\xE5lla minst en siffra.",
    enterAgain: "V\xE4nligen ange ditt l\xF6senord igen.",
    noMatch: "L\xF6senorden du angav matchar inte."
  }
};
const auth = {
  common,
  placeholder,
  signIn,
  signUp,
  reset,
  error
};

export { common, auth as default, error, placeholder, reset, signIn, signUp };
//# sourceMappingURL=auth-1904c53f.mjs.map
