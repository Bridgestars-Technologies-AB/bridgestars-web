const welcome = "Welcome";
const here = "Here";
const home = "Home";
const profile = "Profile";
const policy = "Policy";
const downloads = "Downloads";
const misc = {
  copyright: "Copyright \xA9 {{year}} Bridgestars by Bridgestars Technologies Sweden AB. All rights reserved."
};
const common = {
  welcome,
  here,
  home,
  profile,
  policy,
  downloads,
  misc
};

export { common as default, downloads, here, home, misc, policy, profile, welcome };
//# sourceMappingURL=common-cf0b3750.mjs.map
