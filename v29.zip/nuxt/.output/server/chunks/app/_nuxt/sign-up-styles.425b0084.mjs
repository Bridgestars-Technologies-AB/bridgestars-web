const signUp_vue_vue_type_style_index_0_lang = "";

const signUpStyles_425b0084 = [signUp_vue_vue_type_style_index_0_lang];

export { signUpStyles_425b0084 as default };
//# sourceMappingURL=sign-up-styles.425b0084.mjs.map
