const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.513dfa83.mjs').then(interopDefault),
  "pages/auth/sign-up.vue": () => import('./_nuxt/sign-up-styles.425b0084.mjs').then(interopDefault),
  "pages/dash.vue": () => import('./_nuxt/dash-styles.00bb54fc.mjs').then(interopDefault),
  "pages/dev/db-schema.vue": () => import('./_nuxt/db-schema-styles.fcedc1c7.mjs').then(interopDefault),
  "pages/policy/index.vue": () => import('./_nuxt/index-styles.9f6638d6.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.cf00f4cc.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.a001b7ed.mjs').then(interopDefault),
  "pages/index.vue": () => import('./_nuxt/index-styles.fc9c02c6.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
