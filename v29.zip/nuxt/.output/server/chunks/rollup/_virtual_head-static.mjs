const _virtual__headStatic = {"headTags":"<meta charset=\"utf-8\">\n<title>Bridgestars</title>\n<meta name=\"description\" content=\"Bridgestars provides custom IT solutions.\">\n<meta name=\"viewport\" content=\"width=device-width, height=device-height, initial-scale=1\">\n<script src=\"https://cdnjs.cloudflare.com/ajax/libs/balance-text/3.3.1/balancetext.min.js\"></script>","bodyTags":"","bodyTagsOpen":"","htmlAttrs":"","bodyAttrs":""};

export { _virtual__headStatic as default };
//# sourceMappingURL=_virtual_head-static.mjs.map
