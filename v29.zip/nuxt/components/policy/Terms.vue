<template>
  <div class="w-[100%] bg-[#000000] h-[100px]"></div>
</template>
