import autoAnimate from "@formkit/auto-animate";
export default function autoAnimate(el) {
  return autoAnimate(el);
}
