<template>
  <div class="DefaultLayout h-full">
    <slot></slot>
  </div>
</template>
