<template>
  <div class="SignInLayout">
    <p>sign in layout</p>
    <slot></slot>
  </div>
</template>
