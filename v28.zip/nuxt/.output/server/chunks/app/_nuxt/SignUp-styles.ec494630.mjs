const SignUp_vue_vue_type_style_index_0_lang = "";

const SignUpStyles_ec494630 = [SignUp_vue_vue_type_style_index_0_lang];

export { SignUpStyles_ec494630 as default };
//# sourceMappingURL=SignUp-styles.ec494630.mjs.map
