import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { useSSRContext, defineComponent, mergeProps } from 'vue';
import { u as useRouter } from '../server.mjs';
import { ssrInterpolate, ssrRenderAttr, ssrRenderSlot, ssrRenderAttrs } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import Parse from 'parse/dist/parse.min.js';

const _imports_0 = "" + buildAssetsURL("sign_in.1171b396.svg");
const _imports_1 = "" + buildAssetsURL("logo-trans-512px.6894ce8f.png");
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "AuthForm",
  __ssrInlineRender: true,
  props: ["header", "title", "subtitle", "footer"],
  emits: ["submit"],
  setup(__props, { emit }) {
    useRouter();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="whitespace-nowrap pt-[30px] pl-[30px]" data-v-3a84356d><button class="authHeader normal-case text-home" data-v-3a84356d> Home </button><span class="authHeader text-signIn !opacity-80" data-v-3a84356d>${ssrInterpolate(__props.header)}</span></div><form name="auth-form" data-v-3a84356d><div class="authGrid" data-v-3a84356d><div class="pt-[20px] flex flex-col justify-center items-center content-center" data-v-3a84356d><img class="pt-[10px] w-[50%] h-[80%]" id="sign-in-image"${ssrRenderAttr("src", _imports_0)} alt="Bridgestars sign-in image" data-v-3a84356d></div><div class="authFlex flex flex-col justify-center items-center content-center w-screen h-screen" data-v-3a84356d><img class="w-[64px] h-[64px] mt-5 mb-5"${ssrRenderAttr("src", _imports_1)} alt="Bridgestars logo" data-v-3a84356d><h6 class="zoomIn text-bridgeBlue text-opacity-100 font-bold mb-1" data-v-3a84356d>${ssrInterpolate(__props.title)}</h6><span class="zoomIn text2 mb-6 !text-[14px]" data-v-3a84356d>${ssrInterpolate(__props.subtitle)}</span><div class="zoomIn inputDiv flex flex-col space-y-4 items-center sm:w-[50%] md:w-[40%] lg:w-[35%] xl:w-[30%] max-w-[400px]" data-v-3a84356d>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></div></div></form><!--]-->`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/auth/AuthForm.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-3a84356d"]]);
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "TextInputField",
  __ssrInlineRender: true,
  props: ["placeholder", "id", "wrapperClass"],
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "input-block " + __props.wrapperClass
      }, _attrs))} data-v-b8dd5e1f><input${ssrRenderAttrs(mergeProps({ class: "py-2.5 px-3.5" }, _ctx.$attrs, {
        placeholder: " ",
        id: __props.id
      }))} data-v-b8dd5e1f><span class="placeholder text2 !font-light !text-[14px] !tracking-[1.2px]" data-v-b8dd5e1f>${ssrInterpolate(__props.placeholder)}</span><small class="info" data-v-b8dd5e1f></small></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/base/TextInputField.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-b8dd5e1f"]]);
const _sfc_main = {
  __name: "SubmitButton",
  __ssrInlineRender: true,
  props: ["wrapperClass", "text"],
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "buttonDiv " + __props.wrapperClass
      }, _attrs))} data-v-e48b95bc><button${ssrRenderAttrs(mergeProps({ class: "font-family py-[12px] px-[28px] rounded-[8px] h-[35px] btn tracking-[2px]" }, _ctx.$attrs))} data-v-e48b95bc>${ssrInterpolate(__props.text || "SUBMIT")}</button></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/base/SubmitButton.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-e48b95bc"]]);
const initializeParse = (serverURL, applicationId) => {
  Parse.serverURL = serverURL;
  Parse.initialize(applicationId);
};
initializeParse(
  "https://aws.lb.bridgestars.net/rest",
  "k4PTFS2R8tSYoZC8UNXzvplbZ38jOmViOkJxJEyE"
);

export { __nuxt_component_0 as _, __nuxt_component_1 as a, __nuxt_component_2 as b };
//# sourceMappingURL=parse.config-3c6817de.mjs.map
