const client_manifest = {
  "AuthForm.css": {
    "resourceType": "style",
    "file": "AuthForm.6ac4c286.css",
    "src": "AuthForm.css"
  },
  "_AuthForm.dfeb3021.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "sign_in.1171b396.svg",
      "logo-trans-512px.6894ce8f.png"
    ],
    "css": [
      "AuthForm.6ac4c286.css"
    ],
    "file": "AuthForm.dfeb3021.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ]
  },
  "AuthForm.6ac4c286.css": {
    "file": "AuthForm.6ac4c286.css",
    "resourceType": "style"
  },
  "sign_in.1171b396.svg": {
    "file": "sign_in.1171b396.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "logo-trans-512px.6894ce8f.png": {
    "file": "logo-trans-512px.6894ce8f.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "__plugin-vue_export-helper.c27b6911.js": {
    "resourceType": "script",
    "module": true,
    "file": "_plugin-vue_export-helper.c27b6911.js"
  },
  "_parse.config.c0c6886b.js": {
    "resourceType": "script",
    "module": true,
    "file": "parse.config.c0c6886b.js"
  },
  "assets/bridgestars/art/sign_in.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "sign_in.1171b396.svg",
    "src": "assets/bridgestars/art/sign_in.svg"
  },
  "assets/bridgestars/logo/logo-trans-512px.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo-trans-512px.6894ce8f.png",
    "src": "assets/bridgestars/logo/logo-trans-512px.png"
  },
  "i18n-meta.json": {
    "file": "i18n-meta.json",
    "src": "i18n-meta.json"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "file": "default.7655f964.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "layouts/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "file": "sign-in.c1373072.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/sign-in.vue"
  },
  "localization/lang/en-US.json": {
    "resourceType": "script",
    "module": true,
    "file": "en-US.5ff677b8.js",
    "isDynamicEntry": true,
    "src": "localization/lang/en-US.json"
  },
  "localization/lang/sv-SE.json": {
    "resourceType": "script",
    "module": true,
    "file": "sv-SE.2947716b.js",
    "isDynamicEntry": true,
    "src": "localization/lang/sv-SE.json"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.23f2309d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.6720937c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.23f2309d.css": {
    "file": "error-404.23f2309d.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.aa16ed4d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.216707aa.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.aa16ed4d.css": {
    "file": "error-500.aa16ed4d.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.00780437.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.00780437.css"
    ],
    "dynamicImports": [
      "layouts/default.vue",
      "layouts/sign-in.vue",
      "localization/lang/en-US.json",
      "localization/lang/sv-SE.json",
      "virtual:nuxt:/Users/theo/Documents/bridgestars/lib/bridgestars-web/nuxt/.nuxt/error-component.mjs"
    ],
    "file": "entry.52d5e20e.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.00780437.css": {
    "file": "entry.00780437.css",
    "resourceType": "style"
  },
  "pages/auth/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "file": "forgot-password.51a102da.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/auth/forgot-password.vue"
  },
  "pages/auth/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "file": "sign-in.008be968.js",
    "imports": [
      "_AuthForm.dfeb3021.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_parse.config.c0c6886b.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/auth/sign-in.vue"
  },
  "pages/auth/sign-up.vue": {
    "resourceType": "script",
    "module": true,
    "file": "sign-up.edaf45b5.js",
    "imports": [
      "_AuthForm.dfeb3021.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_parse.config.c0c6886b.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/auth/sign-up.vue"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.d95c55c7.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "pages/policy/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.97f52be9.js",
    "imports": [
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/policy/index.vue"
  },
  "pages/profile/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.f0442dba.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_parse.config.c0c6886b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/profile/index.vue"
  },
  "virtual:nuxt:/Users/theo/Documents/bridgestars/lib/bridgestars-web/nuxt/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "error-component.c680ac50.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:/Users/theo/Documents/bridgestars/lib/bridgestars-web/nuxt/.nuxt/error-component.mjs"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
