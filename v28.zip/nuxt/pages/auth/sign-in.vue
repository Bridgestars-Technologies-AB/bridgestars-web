<script setup></script>

<template>
  <auth-sign-in/>
</template>
